{"_id": "1", "text": "Czy żołnierz, który dopuszcza się czynnej napaści na przełożonego podlega karze pozbawienia wolności?"}
{"_id": "2", "text": "Z ilu osób składa się komisja przetargowa?"}
{"_id": "3", "text": "Do jakiej wysokości za zobowiązania spółki odpowiada komandytariusz?"}
{"_id": "4", "text": "Kiedy ustala się wartość majątku obrotowego, który stracił swoją przydatność?"}
{"_id": "5", "text": "Jakiej karze podlega armator, który wykonuje rybołówstwo morskie w polskich obszarach morskich, z naruszeniem przepisów ustawy?"}
{"_id": "6", "text": "Kogo zwalnia się od akcyzy według zasady wzajemności?"}
{"_id": "7", "text": "Czy żołnierze przy wykonaniu czynności służbowej nie muszą się przedstawiać?"}
{"_id": "8", "text": "Ile budżetów ma miasto na prawach powiatu?"}
{"_id": "9", "text": "Czy żołnierze Żandarmerii Wojskowej mogą uniemożliwiać ich identyfikację podczas wykonywania operacyjno-rozpoznawcze?"}
{"_id": "10", "text": "W jakim przypadku policja może dokonać przeszukania pomieszczeń w domu?"}
{"_id": "11", "text": "Jakim warunkom powinny odpowiadać przekazywane gminie urządzenia wodociągowe?"}
{"_id": "12", "text": "Jakiej karze podlega osoba, która nie stosuje się do ograniczeń w dostarczaniu paliw?"}
{"_id": "13", "text": "Kto wchodzi w skład kolegium doradczego wojewody?"}
{"_id": "14", "text": "Czy poręczenia od Skarbu Państwa są bezterminowe?"}
{"_id": "15", "text": "Co jaki okres funkcjonariusze podlegają opiniowaniu służbowemu?"}
{"_id": "16", "text": "Co zawiera rejestr grup?"}
{"_id": "17", "text": "Czy spółka może udzielać pożyczek na nabycie emitowanych przez nią akcji?"}
{"_id": "18", "text": "Czy poddanie się rehabilitacji jest dobrowolne?"}
{"_id": "19", "text": "Jakie obowiązki ma pracownik nadzorujący czynności kontrolne?"}
{"_id": "20", "text": "Czym jest budżet państwa?"}
{"_id": "21", "text": "Jak ściga się świadczenia w ramach funduszu alimentacyjnego?"}
{"_id": "22", "text": "Co się stanie jeżeli nie zostanie uiszczona opłata dla wniosku patentowego?"}
{"_id": "23", "text": "Jak uniemożliwienić osobom nieuprawnionym dostępu do informacji niejawnych?"}
{"_id": "24", "text": "Jaki jest tygodniowy odpoczynek kierowcy?"}
{"_id": "25", "text": "Do jakich przestępstw nie ma zastosowania część ogólna Kodeksu Karnego?"}
{"_id": "26", "text": "Co robi sąd po wysłuchaniu głosów stron?"}
{"_id": "27", "text": "Czy detektyw podczas pracy może naruszyć prawa obywatela?"}
{"_id": "28", "text": "W jakiej formie wydawana jest zgoda na pobieranie opłat przez urząd skarbowy?"}
{"_id": "29", "text": "Kto wybiera przewodniczącego Rady Krajowego Związku Kas?"}
{"_id": "30", "text": "Na jakiej wartości akcje dzieli się kapitał spółki akcyjnej?"}
{"_id": "31", "text": "Jakiej karze podlega armator, który wykonuje rybołówstwo morskie w polskich obszarach morskich, z naruszeniem przepisów ustawy?"}
{"_id": "32", "text": "Czy żołnierze przy wykonaniu czynności służbowej nie muszą się przedstawiać?"}
{"_id": "33", "text": "W jakim przypadku policja może dokonać przeszukania pomieszczeń w domu?"}
{"_id": "34", "text": "Czy poręczenia od Skarbu Państwa są bezterminowe?"}
{"_id": "35", "text": "Jakie obowiązki ma pracownik nadzorujący czynności kontrolne?"}
{"_id": "36", "text": "Co się stanie jeżeli nie zostanie uiszczona opłata dla wniosku patentowego?"}
{"_id": "37", "text": "Na jakiej wartości akcje dzieli się kapitał spółki akcyjnej?"}
{"_id": "38", "text": "Jakiej karze podlega armator, który wykonuje rybołówstwo morskie w polskich obszarach morskich, z naruszeniem przepisów ustawy?"}
{"_id": "39", "text": "Czy żołnierze Żandarmerii Wojskowej mogą uniemożliwiać ich identyfikację podczas wykonywania operacyjno-rozpoznawcze?"}
{"_id": "40", "text": "W jakim przypadku policja może dokonać przeszukania pomieszczeń w domu?"}
{"_id": "41", "text": "W jakim przypadku policja może dokonać przeszukania pomieszczeń w domu?"}
{"_id": "42", "text": "Jakim warunkom powinny odpowiadać przekazywane gminie urządzenia wodociągowe?"}
{"_id": "43", "text": "Kto wchodzi w skład kolegium doradczego wojewody?"}
{"_id": "44", "text": "Co jaki okres funkcjonariusze podlegają opiniowaniu służbowemu?"}
{"_id": "45", "text": "Co zawiera rejestr grup?"}
{"_id": "46", "text": "Co się stanie jeżeli nie zostanie uiszczona opłata dla wniosku patentowego?"}
{"_id": "47", "text": "Jaki jest tygodniowy odpoczynek kierowcy?"}
{"_id": "48", "text": "Co robi sąd po wysłuchaniu głosów stron?"}
{"_id": "49", "text": "Co robi sąd po wysłuchaniu głosów stron?"}
{"_id": "50", "text": "Kto wybiera przewodniczącego Rady Krajowego Związku Kas?"}
{"_id": "51", "text": "Na jakiej wartości akcje dzieli się kapitał spółki akcyjnej?"}
{"_id": "52", "text": "Na ile wydawna jest licencja na statek rybacki?"}
{"_id": "53", "text": "Jakie zadania wykonują jednostki podległe Szefowi Biura Ochrony Rządu?"}
{"_id": "54", "text": "Kiedy Skarb Państwa może rozwiązać spółkę celową?"}
{"_id": "55", "text": "Czy funkcjonariusze Inspekcji Celnej mogą być wspólnikami w spółkach cywilnych?"}
{"_id": "56", "text": "Czy zamniętych zakładach karnych skazani mogą korzystać z własnych butów?"}
{"_id": "57", "text": "Kto tworzy okręgowe inspektoraty rybołówstwa morskiego?"}
{"_id": "58", "text": "Na jaki okres może zostać pozbawiona wolności osoba, która niszczy cudzą rzecz?"}
{"_id": "59", "text": "Jakiej karze podlega naruszanie czyjejś nietykalności cielesnej z powodu przynależności rasowej?"}
{"_id": "60", "text": "Które miasto jest siedzibą Krajowego Związku Kas?"}
{"_id": "61", "text": "Jakiego dnia ma miejsce Święto Żandarmerii Wojskowej?"}
{"_id": "62", "text": "Kto powołuje rachmistrzów spisowych?"}
{"_id": "63", "text": "Ile godzin na dobę może mieć maksymalnie czas pracy w pięciotygodniowym dniu pracy?"}
{"_id": "64", "text": "Czy małżonkowie może być sędziami w tym samym wydziale sądu?"}
{"_id": "65", "text": "Na jakie obwody dzielą się obwody łowieckie?"}
{"_id": "66", "text": "Ile wynosi zasiłek porodowy?"}
{"_id": "67", "text": "Czy osoba, która odbyła staż urzędniczy w prokuraturze może zostać urzędnikiem?"}
{"_id": "68", "text": "Jakie podmioty tworzą Żandarmerię Wojskową?"}
{"_id": "69", "text": "Ile wynosi odprawa pracownika sądu w związku z przejściem na emeryturę, jeśli prawcował 15 lat w sądzie?"}
{"_id": "70", "text": "Kiedy dopuszczenie środka do ochrony roślin do obrotu może zostać cofnięte?"}
{"_id": "71", "text": "Czy w każdej gminie musi znajdować się biblioteka publiczna?"}
{"_id": "72", "text": "Czy na pierwszy stopień oficerski może zostać mianowana osoba, posiadająca wykształcenie średnie?"}
{"_id": "73", "text": "W jakiej formie powinna zostać sporządzona umowa kredytu?"}
{"_id": "74", "text": "Kto nadaje medal \"Siły Zbrojne w Służbie Ojczyzny\"?"}
{"_id": "75", "text": "Na jaki okres może zostać pozbawiona wolności osoba, która bez zgody kobiety ciężarnej przerywa jej ciąże?"}
{"_id": "76", "text": "Co grozi za obcowanie płciowe z rodzeństwem?"}
{"_id": "77", "text": "Czy żółnieżowi pełniącemu służbę kandydacką przysługuje bezpłatne świadczenie zdrowotne w przypadku ogłoszenia mobilizacji?"}
{"_id": "78", "text": "Jaką karę można otrzymać za nielegalne prowadzenie przedsiębiorstwa maklerskiego?"}
{"_id": "79", "text": "Kogo można nazwać cudzoziemcem?"}
{"_id": "80", "text": "Kto powinien dokonywać badań ciała, jeżeli może ono wywoływać uczucie wstydu?"}
{"_id": "81", "text": "Czy na pierwszy stopień oficerski może zostać mianowana osoba, posiadająca wykształcenie średnie?"}
{"_id": "82", "text": "Kto tworzy okręgowe inspektoraty rybołówstwa morskiego?"}
{"_id": "83", "text": "Kto powołuje rachmistrzów spisowych?"}
{"_id": "84", "text": "Na ile wydawna jest licencja na statek rybacki?"}
{"_id": "85", "text": "Na ile wydawna jest licencja na statek rybacki?"}
{"_id": "86", "text": "Na ile wydawna jest licencja na statek rybacki?"}
{"_id": "87", "text": "Na ile wydawna jest licencja na statek rybacki?"}
{"_id": "88", "text": "Jakie zadania wykonują jednostki podległe Szefowi Biura Ochrony Rządu?"}
{"_id": "89", "text": "Jakie zadania wykonują jednostki podległe Szefowi Biura Ochrony Rządu?"}
{"_id": "90", "text": "Jakie zadania wykonują jednostki podległe Szefowi Biura Ochrony Rządu?"}
{"_id": "91", "text": "Jakie zadania wykonują jednostki podległe Szefowi Biura Ochrony Rządu?"}
{"_id": "92", "text": "Jakie zadania wykonują jednostki podległe Szefowi Biura Ochrony Rządu?"}
{"_id": "93", "text": "Co grozi za wprowadzanie do obrotu mięsa niezdatnego do spożycia?"}
{"_id": "94", "text": "Co grozi za wprowadzanie do obrotu mięsa niezdatnego do spożycia?"}
{"_id": "95", "text": "Co grozi za wprowadzanie do obrotu mięsa niezdatnego do spożycia?"}
{"_id": "96", "text": "Co grozi za wprowadzanie do obrotu mięsa niezdatnego do spożycia?"}
{"_id": "97", "text": "Co grozi za wprowadzanie do obrotu mięsa niezdatnego do spożycia?"}
{"_id": "98", "text": "Kiedy Skarb Państwa może rozwiązać spółkę celową?"}
{"_id": "99", "text": "Kiedy Skarb Państwa może rozwiązać spółkę celową?"}
{"_id": "100", "text": "Kiedy Skarb Państwa może rozwiązać spółkę celową?"}
{"_id": "101", "text": "Kiedy Skarb Państwa może rozwiązać spółkę celową?"}
{"_id": "102", "text": "Czy funkcjonariusze Inspekcji Celnej mogą być wspólnikami w spółkach cywilnych?"}
{"_id": "103", "text": "Czy funkcjonariusze Inspekcji Celnej mogą być wspólnikami w spółkach cywilnych?"}
{"_id": "104", "text": "Czy funkcjonariusze Inspekcji Celnej mogą być wspólnikami w spółkach cywilnych?"}
{"_id": "105", "text": "Czy funkcjonariusze Inspekcji Celnej mogą być wspólnikami w spółkach cywilnych?"}
{"_id": "106", "text": "Czy funkcjonariusze Inspekcji Celnej mogą być wspólnikami w spółkach cywilnych?"}
{"_id": "107", "text": "Czy zamniętych zakładach karnych skazani mogą korzystać z własnych butów?"}
{"_id": "108", "text": "Czy zamniętych zakładach karnych skazani mogą korzystać z własnych butów?"}
{"_id": "109", "text": "Czy zamniętych zakładach karnych skazani mogą korzystać z własnych butów?"}
{"_id": "110", "text": "Czy zamniętych zakładach karnych skazani mogą korzystać z własnych butów?"}
{"_id": "111", "text": "Kto tworzy okręgowe inspektoraty rybołówstwa morskiego?"}
{"_id": "112", "text": "Kto tworzy okręgowe inspektoraty rybołówstwa morskiego?"}
{"_id": "113", "text": "Kto tworzy okręgowe inspektoraty rybołówstwa morskiego?"}
{"_id": "114", "text": "Na jaki okres może zostać pozbawiona wolności osoba, która niszczy cudzą rzecz?"}
{"_id": "115", "text": "Na jaki okres może zostać pozbawiona wolności osoba, która niszczy cudzą rzecz?"}
{"_id": "116", "text": "Na jaki okres może zostać pozbawiona wolności osoba, która niszczy cudzą rzecz?"}
{"_id": "117", "text": "Na jaki okres może zostać pozbawiona wolności osoba, która niszczy cudzą rzecz?"}
{"_id": "118", "text": "Na jaki okres może zostać pozbawiona wolności osoba, która niszczy cudzą rzecz?"}
{"_id": "119", "text": "Jakiej karze podlega naruszanie czyjejś nietykalności cielesnej z powodu przynależności rasowej?"}
{"_id": "120", "text": "Jakiej karze podlega naruszanie czyjejś nietykalności cielesnej z powodu przynależności rasowej?"}
{"_id": "121", "text": "Jakiej karze podlega naruszanie czyjejś nietykalności cielesnej z powodu przynależności rasowej?"}
{"_id": "122", "text": "Jakiej karze podlega naruszanie czyjejś nietykalności cielesnej z powodu przynależności rasowej?"}
{"_id": "123", "text": "Które miasto jest siedzibą Krajowego Związku Kas?"}
{"_id": "124", "text": "Które miasto jest siedzibą Krajowego Związku Kas?"}
{"_id": "125", "text": "Które miasto jest siedzibą Krajowego Związku Kas?"}
{"_id": "126", "text": "Które miasto jest siedzibą Krajowego Związku Kas?"}
{"_id": "127", "text": "Jakiego dnia ma miejsce Święto Żandarmerii Wojskowej?"}
{"_id": "128", "text": "Jakiego dnia ma miejsce Święto Żandarmerii Wojskowej?"}
{"_id": "129", "text": "Jakiego dnia ma miejsce Święto Żandarmerii Wojskowej?"}
{"_id": "130", "text": "Jakiego dnia ma miejsce Święto Żandarmerii Wojskowej?"}
{"_id": "131", "text": "Jakiego dnia ma miejsce Święto Żandarmerii Wojskowej?"}
{"_id": "132", "text": "Kto powołuje rachmistrzów spisowych?"}
{"_id": "133", "text": "Kto powołuje rachmistrzów spisowych?"}
{"_id": "134", "text": "Kto powołuje rachmistrzów spisowych?"}
{"_id": "135", "text": "Kto powołuje rachmistrzów spisowych?"}
{"_id": "136", "text": "Ile godzin na dobę może mieć maksymalnie czas pracy w pięciotygodniowym dniu pracy?"}
{"_id": "137", "text": "Ile godzin na dobę może mieć maksymalnie czas pracy w pięciotygodniowym dniu pracy?"}
{"_id": "138", "text": "Ile godzin na dobę może mieć maksymalnie czas pracy w pięciotygodniowym dniu pracy?"}
{"_id": "139", "text": "Ile godzin na dobę może mieć maksymalnie czas pracy w pięciotygodniowym dniu pracy?"}
{"_id": "140", "text": "Czy małżonkowie może być sędziami w tym samym wydziale sądu?"}
{"_id": "141", "text": "Czy małżonkowie może być sędziami w tym samym wydziale sądu?"}
{"_id": "142", "text": "Czy małżonkowie może być sędziami w tym samym wydziale sądu?"}
{"_id": "143", "text": "Na jakie obwody dzielą się obwody łowieckie?"}
{"_id": "144", "text": "Na jakie obwody dzielą się obwody łowieckie?"}
{"_id": "145", "text": "Na jakie obwody dzielą się obwody łowieckie?"}
{"_id": "146", "text": "Na jakie obwody dzielą się obwody łowieckie?"}
{"_id": "147", "text": "Ile wynosi zasiłek porodowy?"}
{"_id": "148", "text": "Ile wynosi zasiłek porodowy?"}
{"_id": "149", "text": "Ile wynosi zasiłek porodowy?"}
{"_id": "150", "text": "Ile wynosi zasiłek porodowy?"}
{"_id": "151", "text": "Czy osoba, która odbyła staż urzędniczy w prokuraturze może zostać urzędnikiem?"}
{"_id": "152", "text": "Czy osoba, która odbyła staż urzędniczy w prokuraturze może zostać urzędnikiem?"}
{"_id": "153", "text": "Czy osoba, która odbyła staż urzędniczy w prokuraturze może zostać urzędnikiem?"}
{"_id": "154", "text": "Czy osoba, która odbyła staż urzędniczy w prokuraturze może zostać urzędnikiem?"}
{"_id": "155", "text": "Jakie podmioty tworzą Żandarmerię Wojskową?"}
{"_id": "156", "text": "Jakie podmioty tworzą Żandarmerię Wojskową?"}
{"_id": "157", "text": "Jakie podmioty tworzą Żandarmerię Wojskową?"}
{"_id": "158", "text": "Jakie podmioty tworzą Żandarmerię Wojskową?"}
{"_id": "159", "text": "Ile wynosi odprawa pracownika sądu w związku z przejściem na emeryturę, jeśli prawcował 15 lat w sądzie?"}
{"_id": "160", "text": "Ile wynosi odprawa pracownika sądu w związku z przejściem na emeryturę, jeśli prawcował 15 lat w sądzie?"}
{"_id": "161", "text": "Ile wynosi odprawa pracownika sądu w związku z przejściem na emeryturę, jeśli prawcował 15 lat w sądzie?"}
{"_id": "162", "text": "Ile wynosi odprawa pracownika sądu w związku z przejściem na emeryturę, jeśli prawcował 15 lat w sądzie?"}
{"_id": "163", "text": "Kiedy dopuszczenie środka do ochrony roślin do obrotu może zostać cofnięte?"}
{"_id": "164", "text": "Kiedy dopuszczenie środka do ochrony roślin do obrotu może zostać cofnięte?"}
{"_id": "165", "text": "Kiedy dopuszczenie środka do ochrony roślin do obrotu może zostać cofnięte?"}
{"_id": "166", "text": "Kiedy dopuszczenie środka do ochrony roślin do obrotu może zostać cofnięte?"}
{"_id": "167", "text": "Czy w każdej gminie musi znajdować się biblioteka publiczna?"}
{"_id": "168", "text": "Czy w każdej gminie musi znajdować się biblioteka publiczna?"}
{"_id": "169", "text": "Czy w każdej gminie musi znajdować się biblioteka publiczna?"}
{"_id": "170", "text": "Czy w każdej gminie musi znajdować się biblioteka publiczna?"}
{"_id": "171", "text": "Czy na pierwszy stopień oficerski może zostać mianowana osoba, posiadająca wykształcenie średnie?"}
{"_id": "172", "text": "Czy na pierwszy stopień oficerski może zostać mianowana osoba, posiadająca wykształcenie średnie?"}
{"_id": "173", "text": "Czy na pierwszy stopień oficerski może zostać mianowana osoba, posiadająca wykształcenie średnie?"}
{"_id": "174", "text": "W jakiej formie powinna zostać sporządzona umowa kredytu?"}
{"_id": "175", "text": "W jakiej formie powinna zostać sporządzona umowa kredytu?"}
{"_id": "176", "text": "W jakiej formie powinna zostać sporządzona umowa kredytu?"}
{"_id": "177", "text": "W jakiej formie powinna zostać sporządzona umowa kredytu?"}
{"_id": "178", "text": "Kto nadaje medal \"Siły Zbrojne w Służbie Ojczyzny\"?"}
{"_id": "179", "text": "Kto nadaje medal \"Siły Zbrojne w Służbie Ojczyzny\"?"}
{"_id": "180", "text": "Kto nadaje medal \"Siły Zbrojne w Służbie Ojczyzny\"?"}
{"_id": "181", "text": "Kto nadaje medal \"Siły Zbrojne w Służbie Ojczyzny\"?"}
{"_id": "182", "text": "Na jaki okres może zostać pozbawiona wolności osoba, która bez zgody kobiety ciężarnej przerywa jej ciąże?"}
{"_id": "183", "text": "Na jaki okres może zostać pozbawiona wolności osoba, która bez zgody kobiety ciężarnej przerywa jej ciąże?"}
{"_id": "184", "text": "Na jaki okres może zostać pozbawiona wolności osoba, która bez zgody kobiety ciężarnej przerywa jej ciąże?"}
{"_id": "185", "text": "Na jaki okres może zostać pozbawiona wolności osoba, która bez zgody kobiety ciężarnej przerywa jej ciąże?"}
{"_id": "186", "text": "Co grozi za obcowanie płciowe z rodzeństwem?"}
{"_id": "187", "text": "Co grozi za obcowanie płciowe z rodzeństwem?"}
{"_id": "188", "text": "Co grozi za obcowanie płciowe z rodzeństwem?"}
{"_id": "189", "text": "Co grozi za obcowanie płciowe z rodzeństwem?"}
{"_id": "190", "text": "Czy żółnieżowi pełniącemu służbę kandydacką przysługuje bezpłatne świadczenie zdrowotne w przypadku ogłoszenia mobilizacji?"}
{"_id": "191", "text": "Czy żółnieżowi pełniącemu służbę kandydacką przysługuje bezpłatne świadczenie zdrowotne w przypadku ogłoszenia mobilizacji?"}
{"_id": "192", "text": "Czy żółnieżowi pełniącemu służbę kandydacką przysługuje bezpłatne świadczenie zdrowotne w przypadku ogłoszenia mobilizacji?"}
{"_id": "193", "text": "Czy żółnieżowi pełniącemu służbę kandydacką przysługuje bezpłatne świadczenie zdrowotne w przypadku ogłoszenia mobilizacji?"}
{"_id": "194", "text": "Czy żółnieżowi pełniącemu służbę kandydacką przysługuje bezpłatne świadczenie zdrowotne w przypadku ogłoszenia mobilizacji?"}
{"_id": "195", "text": "Jaką karę można otrzymać za nielegalne prowadzenie przedsiębiorstwa maklerskiego?"}
{"_id": "196", "text": "Jaką karę można otrzymać za nielegalne prowadzenie przedsiębiorstwa maklerskiego?"}
{"_id": "197", "text": "Jaką karę można otrzymać za nielegalne prowadzenie przedsiębiorstwa maklerskiego?"}
{"_id": "198", "text": "Jaką karę można otrzymać za nielegalne prowadzenie przedsiębiorstwa maklerskiego?"}
{"_id": "199", "text": "Jaką karę można otrzymać za nielegalne prowadzenie przedsiębiorstwa maklerskiego?"}
{"_id": "200", "text": "Kogo można nazwać cudzoziemcem?"}
{"_id": "201", "text": "Kogo można nazwać cudzoziemcem?"}
{"_id": "202", "text": "Kogo można nazwać cudzoziemcem?"}
{"_id": "203", "text": "Kogo można nazwać cudzoziemcem?"}
{"_id": "204", "text": "Kto powinien dokonywać badań ciała, jeżeli może ono wywoływać uczucie wstydu?"}
{"_id": "205", "text": "Kto powinien dokonywać badań ciała, jeżeli może ono wywoływać uczucie wstydu?"}
{"_id": "206", "text": "Kto powinien dokonywać badań ciała, jeżeli może ono wywoływać uczucie wstydu?"}
{"_id": "207", "text": "Kto powinien dokonywać badań ciała, jeżeli może ono wywoływać uczucie wstydu?"}
{"_id": "208", "text": "Na czyj wniosek Rada Ministrów ustala cenę minimalną ziemniaków?"}
{"_id": "209", "text": "Do czego zobowiązane są organy Państwowej Straży Pożarnej w razie wystąpienia awarii przemysłowej?"}
{"_id": "210", "text": "Co ogłasza się w Biuletynie Zamówień Publicznych?"}
{"_id": "211", "text": "Co to jest dzień bilansowy?"}
{"_id": "212", "text": "W jakim terminie środki Biura Hydrograficznego podlegają przekazaniu"}
{"_id": "213", "text": "Kto może emitować obligacje?"}
{"_id": "214", "text": "Ile wynosi opłata na rzecz Klubu?"}
{"_id": "215", "text": "Czy udziałowcy mogą ponieść  odpowiedzialność za straty powstałe w banku?"}
{"_id": "216", "text": "Jaka kwota zostanie przekazana gmimon na sfinansowanie wypłat dla pracowników szkół?"}
{"_id": "217", "text": "Czy skazany który nie ukończył 18 lat musi mieć obrońcę?"}
{"_id": "218", "text": "Czy Minister Edukacji sprawuje nadzór nad sądami wojskowymi?"}
{"_id": "219", "text": "Czy ceny i stawki określone w taryfie są stałe dla wszystkich grup odbiorców?"}
{"_id": "220", "text": "Kto określa zasady pocztowej kontroli dewizowej?"}
{"_id": "221", "text": "Kiedy zostają założone gimnazja?"}
{"_id": "222", "text": "Gdzie jest siedziba Uniwersytetu Warmińsko-Mazurskiego?"}
{"_id": "223", "text": "Kiedy Prezes Rady Ministrów może odstąpić od obowiązku ogłoszenia umowy międzynarodowej w Monitorze Polski?"}
{"_id": "224", "text": "Do czego zobowiązana jest osoba która wprowadziła do obrotu nawozy niezgodnie z warunkami określonymi w art. 3?"}
{"_id": "225", "text": "Jak duża strefa wokół Pomnika Zagłady jest chroniona?"}
{"_id": "226", "text": "Jak Krajowy Komitet do Spraw Systemu Zbierania i Wykorzystywania Danych Rachunkowych z Gospodarstw Rolnych wydaje opinie?"}
{"_id": "227", "text": "Jaka kwota dotacji została ustalona dla podręczników szkolnych do kształcenia zawodowego?"}
{"_id": "228", "text": "Kto tworzy Polską Izbę Rzeczników patentowych?"}
{"_id": "229", "text": "Czy Rzecznik patentowy jest zobowiązwany do opłacania składek?"}
{"_id": "230", "text": "Czy wydział wojskowy należy do wydziałów sądu okręgowego?"}
{"_id": "231", "text": "Do kiedy uważa się za spełniony wymóg odbycia aplikacji dyplomatyczno-konsularną?"}
{"_id": "232", "text": "Jakie prezepisy stosuje się do rozpatrywania skarg w związki z realizacją Euro 2012?"}
{"_id": "233", "text": "Co się dzieje w przypadku stwierdzenia że przywóz towaru objętego postępowaniem jest nadmierny?"}
{"_id": "234", "text": "Kto opracowuje plan zapewnienia bezpieczeństwa i porządku publicznego podczas Konferencji COP24?"}
{"_id": "235", "text": "Kiedy wygasa członkostwo w Radzie?"}
{"_id": "236", "text": "Co ogłasza się w Biuletynie Zamówień Publicznych?"}
{"_id": "237", "text": "Co ogłasza się w Biuletynie Zamówień Publicznych?"}
{"_id": "238", "text": "Co ogłasza się w Biuletynie Zamówień Publicznych?"}
{"_id": "239", "text": "Co to jest dzień bilansowy?"}
{"_id": "240", "text": "Co to jest dzień bilansowy?"}
{"_id": "241", "text": "Kto może emitować obligacje?"}
{"_id": "242", "text": "Ile wynosi opłata na rzecz Klubu?"}
{"_id": "243", "text": "Czy udziałowcy mogą ponieść  odpowiedzialność za straty powstałe w banku?"}
{"_id": "244", "text": "Czy skazany który nie ukończył 18 lat musi mieć obrońcę?"}
{"_id": "245", "text": "Czy Minister Edukacji sprawuje nadzór nad sądami wojskowymi?"}
{"_id": "246", "text": "Czy Minister Edukacji sprawuje nadzór nad sądami wojskowymi?"}
{"_id": "247", "text": "Kto określa zasady pocztowej kontroli dewizowej?"}
{"_id": "248", "text": "Kiedy zostają założone gimnazja?"}
{"_id": "249", "text": "Kiedy zostają założone gimnazja?"}
{"_id": "250", "text": "Kiedy Prezes Rady Ministrów może odstąpić od obowiązku ogłoszenia umowy międzynarodowej w Monitorze Polski?"}
{"_id": "251", "text": "Do czego zobowiązana jest osoba która wprowadziła do obrotu nawozy niezgodnie z warunkami określonymi w art. 3?"}
{"_id": "252", "text": "Jak duża strefa wokół Pomnika Zagłady jest chroniona?"}
{"_id": "253", "text": "Jak duża strefa wokół Pomnika Zagłady jest chroniona?"}
{"_id": "254", "text": "Jaka kwota dotacji została ustalona dla podręczników szkolnych do kształcenia zawodowego?"}
{"_id": "255", "text": "Jaka kwota dotacji została ustalona dla podręczników szkolnych do kształcenia zawodowego?"}
{"_id": "256", "text": "Czy wydział wojskowy należy do wydziałów sądu okręgowego?"}
{"_id": "257", "text": "Co się dzieje w przypadku stwierdzenia że przywóz towaru objętego postępowaniem jest nadmierny?"}
{"_id": "258", "text": "Co się dzieje w przypadku stwierdzenia że przywóz towaru objętego postępowaniem jest nadmierny?"}
{"_id": "259", "text": "Co się dzieje w przypadku stwierdzenia że przywóz towaru objętego postępowaniem jest nadmierny?"}
{"_id": "260", "text": "Co się dzieje w przypadku stwierdzenia że przywóz towaru objętego postępowaniem jest nadmierny?"}
{"_id": "261", "text": "Kto opracowuje plan zapewnienia bezpieczeństwa i porządku publicznego podczas Konferencji COP24?"}
{"_id": "262", "text": "Kto opracowuje plan zapewnienia bezpieczeństwa i porządku publicznego podczas Konferencji COP24?"}
{"_id": "263", "text": "Kto opracowuje plan zapewnienia bezpieczeństwa i porządku publicznego podczas Konferencji COP24?"}
{"_id": "264", "text": "Kto opracowuje plan zapewnienia bezpieczeństwa i porządku publicznego podczas Konferencji COP24?"}
{"_id": "265", "text": "Kto opracowuje plan zapewnienia bezpieczeństwa i porządku publicznego podczas Konferencji COP24?"}
{"_id": "266", "text": "Kiedy wygasa członkostwo w Radzie?"}
{"_id": "267", "text": "Kiedy wygasa członkostwo w Radzie?"}
{"_id": "268", "text": "Kiedy wygasa członkostwo w Radzie?"}
{"_id": "269", "text": "Co to jest margines dumpingu?"}
{"_id": "270", "text": "Co grozi za podglądanie głosów innych osób podczas wyborów?"}
{"_id": "271", "text": "Co grozi za podglądanie głosów innych osób podczas wyborów?"}
{"_id": "272", "text": "Co grozi za podglądanie głosów innych osób podczas wyborów?"}
{"_id": "273", "text": "Co należy zrobić, tworząc standard jakości środowiska?"}
{"_id": "274", "text": "Co to jest zaległość podatkowa?"}
{"_id": "275", "text": "Co znajduję się w rejestrze detektywów?"}
{"_id": "276", "text": "Czego nie można używać do cumowania statku?"}
{"_id": "277", "text": "Czy farmaceuta może odmówić wydania leku?"}
{"_id": "278", "text": "Czy legalne jest przyjęcie pieniędzy za złożenie podpisu pod kandydaturą na senatora?"}
{"_id": "279", "text": "Czy transakcja wykonana na giełdzie jest grą losową?"}
{"_id": "280", "text": "Czy wniosek o specjalne zezwolenie połowowe pozwala na rybołówstwo jeszcze w tym samym roku?"}
{"_id": "281", "text": "Czy wydawanie przez komitet wyborczy pieniędzy po wyborach jest nielegalne?"}
{"_id": "282", "text": "Do kogo należy oznakowanie nawigacyjne w portach?"}
{"_id": "283", "text": "Jak brzmi treść przyrzeczenia, które musi złożyć biegły sądowy?"}
{"_id": "284", "text": "Jak często odbywa się okręgowe zgromadzenie kuratorów?"}
{"_id": "285", "text": "Jaka kara grozi za podżeganie świadków?"}
{"_id": "286", "text": "Jakie muszą być minimalne udziały przy podziale spółki handlowej?"}
{"_id": "287", "text": "Jakie statki mogą łowić w polskim morzu?"}
{"_id": "288", "text": "Jakie statki mogą łowić w polskim morzu?"}
{"_id": "289", "text": "Kiedy komitet wyborczy może zacząć wydawać pieniądze?"}
{"_id": "290", "text": "Kiedy obrońca sądowy może bronić więcej niż jednego klienta?"}
{"_id": "291", "text": "Kiedy osoby powołane do służby kandydackiej zostają żołnierzami?"}
{"_id": "292", "text": "Kto jest przełożonym żołnierzy?"}
{"_id": "293", "text": "Kto może powołać sekretarza komitetu?"}
{"_id": "294", "text": "Kto może łowić ryby w polskim morzu?"}
{"_id": "295", "text": "Kto może łowić ryby w polskim morzu?"}
{"_id": "296", "text": "Kto może łowić ryby w polskim morzu?"}
{"_id": "297", "text": "Kto odpowiada za rozszerzanie przepisów dotyczących upraw roślin, z których tworzy się narkotyki?"}
{"_id": "298", "text": "Kto określa wzór certyfikatu okrętowego?"}
{"_id": "299", "text": "Kto określa wzór certyfikatu okrętowego?"}
{"_id": "300", "text": "Kto ustala pensję członków Rady Ministrów?"}
{"_id": "301", "text": "Kto wykonuje prawa za ofiarę, jeżeli jest ona niepełnoletnia?"}
{"_id": "302", "text": "Którym członkom Rady Ministrów nie przysługuje wynagrodzenie?"}
{"_id": "303", "text": "Na co komitet wyborczy może wydać pozyskane pieniądze?"}
{"_id": "304", "text": "O co muszą zadbać osoby, które wytwarzają odpady z substancjami kontrolowanymi?"}
{"_id": "305", "text": "O co muszą zadbać osoby, które wytwarzają odpady z substancjami kontrolowanymi?"}
{"_id": "306", "text": "Za co odpowiada fundusz inwestycyjny zamknięty?"}
{"_id": "307", "text": "Za co odpowiada fundusz inwestycyjny zamknięty?"}
{"_id": "308", "text": "Co grozi za podglądanie głosów innych osób podczas wyborów?"}
{"_id": "309", "text": "Co grozi za podglądanie głosów innych osób podczas wyborów?"}
{"_id": "310", "text": "Co grozi za podglądanie głosów innych osób podczas wyborów?"}
{"_id": "311", "text": "Co grozi za podglądanie głosów innych osób podczas wyborów?"}
{"_id": "312", "text": "Co należy zrobić, tworząc standard jakości środowiska?"}
{"_id": "313", "text": "Co należy zrobić, tworząc standard jakości środowiska?"}
{"_id": "314", "text": "Co należy zrobić, tworząc standard jakości środowiska?"}
{"_id": "315", "text": "Co należy zrobić, tworząc standard jakości środowiska?"}
{"_id": "316", "text": "Co to jest zaległość podatkowa?"}
{"_id": "317", "text": "Co to jest zaległość podatkowa?"}
{"_id": "318", "text": "Co to jest zaległość podatkowa?"}
{"_id": "319", "text": "Co to jest zaległość podatkowa?"}
{"_id": "320", "text": "Co to jest zaległość podatkowa?"}
{"_id": "321", "text": "Co to jest zaległość podatkowa?"}
{"_id": "322", "text": "Co znajduję się w rejestrze detektywów?"}
{"_id": "323", "text": "Co znajduję się w rejestrze detektywów?"}
{"_id": "324", "text": "Co znajduję się w rejestrze detektywów?"}
{"_id": "325", "text": "Co znajduję się w rejestrze detektywów?"}
{"_id": "326", "text": "Czego nie można używać do cumowania statku?"}
{"_id": "327", "text": "Czego nie można używać do cumowania statku?"}
{"_id": "328", "text": "Czego nie można używać do cumowania statku?"}
{"_id": "329", "text": "Czego nie można używać do cumowania statku?"}
{"_id": "330", "text": "Czego nie można używać do cumowania statku?"}
{"_id": "331", "text": "Czego nie można używać do cumowania statku?"}
{"_id": "332", "text": "Czy farmaceuta może odmówić wydania leku?"}
{"_id": "333", "text": "Czy farmaceuta może odmówić wydania leku?"}
{"_id": "334", "text": "Czy farmaceuta może odmówić wydania leku?"}
{"_id": "335", "text": "Czy farmaceuta może odmówić wydania leku?"}
{"_id": "336", "text": "Czy farmaceuta może odmówić wydania leku?"}
{"_id": "337", "text": "Czy legalne jest przyjęcie pieniędzy za złożenie podpisu pod kandydaturą na senatora?"}
{"_id": "338", "text": "Czy legalne jest przyjęcie pieniędzy za złożenie podpisu pod kandydaturą na senatora?"}
{"_id": "339", "text": "Czy legalne jest przyjęcie pieniędzy za złożenie podpisu pod kandydaturą na senatora?"}
{"_id": "340", "text": "Czy legalne jest przyjęcie pieniędzy za złożenie podpisu pod kandydaturą na senatora?"}
{"_id": "341", "text": "Czy transakcja wykonana na giełdzie jest grą losową?"}
{"_id": "342", "text": "Czy transakcja wykonana na giełdzie jest grą losową?"}
{"_id": "343", "text": "Czy transakcja wykonana na giełdzie jest grą losową?"}
{"_id": "344", "text": "Czy transakcja wykonana na giełdzie jest grą losową?"}
{"_id": "345", "text": "Czy wniosek o specjalne zezwolenie połowowe pozwala na rybołówstwo jeszcze w tym samym roku?"}
{"_id": "346", "text": "Czy wniosek o specjalne zezwolenie połowowe pozwala na rybołówstwo jeszcze w tym samym roku?"}
{"_id": "347", "text": "Czy wniosek o specjalne zezwolenie połowowe pozwala na rybołówstwo jeszcze w tym samym roku?"}
{"_id": "348", "text": "Czy wydawanie przez komitet wyborczy pieniędzy po wyborach jest nielegalne?"}
{"_id": "349", "text": "Czy wydawanie przez komitet wyborczy pieniędzy po wyborach jest nielegalne?"}
{"_id": "350", "text": "Czy wydawanie przez komitet wyborczy pieniędzy po wyborach jest nielegalne?"}
{"_id": "351", "text": "Czy wydawanie przez komitet wyborczy pieniędzy po wyborach jest nielegalne?"}
{"_id": "352", "text": "Czy wydawanie przez komitet wyborczy pieniędzy po wyborach jest nielegalne?"}
{"_id": "353", "text": "Do kogo należy oznakowanie nawigacyjne w portach?"}
{"_id": "354", "text": "Do kogo należy oznakowanie nawigacyjne w portach?"}
{"_id": "355", "text": "Do kogo należy oznakowanie nawigacyjne w portach?"}
{"_id": "356", "text": "Do kogo należy oznakowanie nawigacyjne w portach?"}
{"_id": "357", "text": "Jak brzmi treść przyrzeczenia, które musi złożyć biegły sądowy?"}
{"_id": "358", "text": "Jak brzmi treść przyrzeczenia, które musi złożyć biegły sądowy?"}
{"_id": "359", "text": "Jak brzmi treść przyrzeczenia, które musi złożyć biegły sądowy?"}
{"_id": "360", "text": "Jak brzmi treść przyrzeczenia, które musi złożyć biegły sądowy?"}
{"_id": "361", "text": "Jak często odbywa się okręgowe zgromadzenie kuratorów?"}
{"_id": "362", "text": "Jak często odbywa się okręgowe zgromadzenie kuratorów?"}
{"_id": "363", "text": "Jak często odbywa się okręgowe zgromadzenie kuratorów?"}
{"_id": "364", "text": "Jak często odbywa się okręgowe zgromadzenie kuratorów?"}
{"_id": "365", "text": "Jaka kara grozi za podżeganie świadków?"}
{"_id": "366", "text": "Jaka kara grozi za podżeganie świadków?"}
{"_id": "367", "text": "Jaka kara grozi za podżeganie świadków?"}
{"_id": "368", "text": "Jaka kara grozi za podżeganie świadków?"}
{"_id": "369", "text": "Jaka kara grozi za podżeganie świadków?"}
{"_id": "370", "text": "Jakie muszą być minimalne udziały przy podziale spółki handlowej?"}
{"_id": "371", "text": "Jakie muszą być minimalne udziały przy podziale spółki handlowej?"}
{"_id": "372", "text": "Jakie muszą być minimalne udziały przy podziale spółki handlowej?"}
{"_id": "373", "text": "Jakie muszą być minimalne udziały przy podziale spółki handlowej?"}
{"_id": "374", "text": "Jakie muszą być minimalne udziały przy podziale spółki handlowej?"}
{"_id": "375", "text": "Jakie statki mogą łowić w polskim morzu?"}
{"_id": "376", "text": "Jakie statki mogą łowić w polskim morzu?"}
{"_id": "377", "text": "Jakie statki mogą łowić w polskim morzu?"}
{"_id": "378", "text": "Jakie statki mogą łowić w polskim morzu?"}
{"_id": "379", "text": "Kiedy komitet wyborczy może zacząć wydawać pieniądze?"}
{"_id": "380", "text": "Kiedy komitet wyborczy może zacząć wydawać pieniądze?"}
{"_id": "381", "text": "Kiedy komitet wyborczy może zacząć wydawać pieniądze?"}
{"_id": "382", "text": "Kiedy komitet wyborczy może zacząć wydawać pieniądze?"}
{"_id": "383", "text": "Kiedy komitet wyborczy może zacząć wydawać pieniądze?"}
{"_id": "384", "text": "Kiedy obrońca sądowy może bronić więcej niż jednego klienta?"}
{"_id": "385", "text": "Kiedy obrońca sądowy może bronić więcej niż jednego klienta?"}
{"_id": "386", "text": "Kiedy obrońca sądowy może bronić więcej niż jednego klienta?"}
{"_id": "387", "text": "Kiedy obrońca sądowy może bronić więcej niż jednego klienta?"}
{"_id": "388", "text": "Kiedy obrońca sądowy może bronić więcej niż jednego klienta?"}
{"_id": "389", "text": "Kiedy osoby powołane do służby kandydackiej zostają żołnierzami?"}
{"_id": "390", "text": "Kiedy osoby powołane do służby kandydackiej zostają żołnierzami?"}
{"_id": "391", "text": "Kiedy osoby powołane do służby kandydackiej zostają żołnierzami?"}
{"_id": "392", "text": "Kto jest przełożonym żołnierzy?"}
{"_id": "393", "text": "Kto jest przełożonym żołnierzy?"}
{"_id": "394", "text": "Kto jest przełożonym żołnierzy?"}
{"_id": "395", "text": "Kto może powołać sekretarza komitetu?"}
{"_id": "396", "text": "Kto może powołać sekretarza komitetu?"}
{"_id": "397", "text": "Kto może powołać sekretarza komitetu?"}
{"_id": "398", "text": "Kto może łowić ryby w polskim morzu?"}
{"_id": "399", "text": "Kto może łowić ryby w polskim morzu?"}
{"_id": "400", "text": "Kto może łowić ryby w polskim morzu?"}
{"_id": "401", "text": "Kto odpowiada za rozszerzanie przepisów dotyczących upraw roślin, z których tworzy się narkotyki?"}
{"_id": "402", "text": "Kto odpowiada za rozszerzanie przepisów dotyczących upraw roślin, z których tworzy się narkotyki?"}
{"_id": "403", "text": "Kto odpowiada za rozszerzanie przepisów dotyczących upraw roślin, z których tworzy się narkotyki?"}
{"_id": "404", "text": "Kto odpowiada za rozszerzanie przepisów dotyczących upraw roślin, z których tworzy się narkotyki?"}
{"_id": "405", "text": "Kto odpowiada za rozszerzanie przepisów dotyczących upraw roślin, z których tworzy się narkotyki?"}
{"_id": "406", "text": "Kto określa wzór certyfikatu okrętowego?"}
{"_id": "407", "text": "Kto określa wzór certyfikatu okrętowego?"}
{"_id": "408", "text": "Kto określa wzór certyfikatu okrętowego?"}
{"_id": "409", "text": "Kto ustala pensję członków Rady Ministrów?"}
{"_id": "410", "text": "Kto ustala pensję członków Rady Ministrów?"}
{"_id": "411", "text": "Kto ustala pensję członków Rady Ministrów?"}
{"_id": "412", "text": "Kto ustala pensję członków Rady Ministrów?"}
{"_id": "413", "text": "Kto ustala pensję członków Rady Ministrów?"}
{"_id": "414", "text": "Kto ustala pensję członków Rady Ministrów?"}
{"_id": "415", "text": "Kto wykonuje prawa za ofiarę, jeżeli jest ona niepełnoletnia?"}
{"_id": "416", "text": "Kto wykonuje prawa za ofiarę, jeżeli jest ona niepełnoletnia?"}
{"_id": "417", "text": "Kto wykonuje prawa za ofiarę, jeżeli jest ona niepełnoletnia?"}
{"_id": "418", "text": "Kto wykonuje prawa za ofiarę, jeżeli jest ona niepełnoletnia?"}
{"_id": "419", "text": "Kto wykonuje prawa za ofiarę, jeżeli jest ona niepełnoletnia?"}
{"_id": "420", "text": "Kto wykonuje prawa za ofiarę, jeżeli jest ona niepełnoletnia?"}
{"_id": "421", "text": "Którym członkom Rady Ministrów nie przysługuje wynagrodzenie?"}
{"_id": "422", "text": "Którym członkom Rady Ministrów nie przysługuje wynagrodzenie?"}
{"_id": "423", "text": "Którym członkom Rady Ministrów nie przysługuje wynagrodzenie?"}
{"_id": "424", "text": "Którym członkom Rady Ministrów nie przysługuje wynagrodzenie?"}
{"_id": "425", "text": "Na co komitet wyborczy może wydać pozyskane pieniądze?"}
{"_id": "426", "text": "Na co komitet wyborczy może wydać pozyskane pieniądze?"}
{"_id": "427", "text": "Na co komitet wyborczy może wydać pozyskane pieniądze?"}
{"_id": "428", "text": "Na co komitet wyborczy może wydać pozyskane pieniądze?"}
{"_id": "429", "text": "Na co komitet wyborczy może wydać pozyskane pieniądze?"}
{"_id": "430", "text": "Na co komitet wyborczy może wydać pozyskane pieniądze?"}
{"_id": "431", "text": "O co muszą zadbać osoby, które wytwarzają odpady z substancjami kontrolowanymi?"}
{"_id": "432", "text": "O co muszą zadbać osoby, które wytwarzają odpady z substancjami kontrolowanymi?"}
{"_id": "433", "text": "O co muszą zadbać osoby, które wytwarzają odpady z substancjami kontrolowanymi?"}
{"_id": "434", "text": "Za co odpowiada fundusz inwestycyjny zamknięty?"}
{"_id": "435", "text": "Za co odpowiada fundusz inwestycyjny zamknięty?"}
{"_id": "436", "text": "Za co odpowiada fundusz inwestycyjny zamknięty?"}
{"_id": "437", "text": "Za co odpowiada fundusz inwestycyjny zamknięty?"}
{"_id": "438", "text": "Jakie instytucje są organami dochodzenia w sprawach o przestępstwa skarbowe i wykroczenia?"}
{"_id": "439", "text": "Jakiej zdolności nie można pozbawiać zwierząt używanych do doświadczeń?"}
{"_id": "440", "text": "Kiedy emisję obligacji uważa się za niedoszłą do skutku?"}
{"_id": "441", "text": "Jak długo trwa obowiązkowa kwarantanna dla osób zdrowych, które pozostawały w styczności z chorymi na dżumę płucną?"}
{"_id": "442", "text": "Ile razy w roku przysługuje żołnierzowi zawodowemu prawo do gratyfikacji urlopowej?"}
{"_id": "443", "text": "Jaki procent uprawnionych do głosowania musi wziąć udział w referendum, żeby było ono ważne?"}
{"_id": "444", "text": "Kto wykonuje funkcje konsula?"}
{"_id": "445", "text": "Ile co najmniej wynosi okres przestawiania chowu zwierząt na produkcję metodami ekologicznymi w przypadku kur niosek?"}
{"_id": "446", "text": "Kto prowadzi rejestr zezwoleń na prowadzenie aptek ogólnodostępnych?"}
{"_id": "447", "text": "Co zawiera informacja o osobie, sporządzona na podstawie danych osobowych zgromadzonych w Rejestrze?"}
{"_id": "448", "text": "Od jakiego dnia każdego roku nalicza się podwyższenie indywidualnych wynagrodzeń urzędników?"}
{"_id": "449", "text": "Jakie są zadania gmin w ramach prac związanych ze spisem?"}
{"_id": "450", "text": "Co obowiązany jest mieć przy sobie kierowca pojazdu samochodowego podczas przejazdu wykonywanego w ramach transportu drogowego?"}
{"_id": "451", "text": "Kogo minister właściwy do spraw transportu może upoważnić do wydawania zezwoleń zagranicznych?"}
{"_id": "452", "text": "Kto wchodzi w skład komisji rewizyjnej powoływanej przez radę powiatu?"}
{"_id": "453", "text": "Jakie są stawki kar za zniszczenie jednego metra kwadratowego terenu zieleni?"}
{"_id": "454", "text": "W jakiej sytuacji przy przewozie na podstawie umowy bukingowej zawiadomienie frachtującego o czasie i miejscu ładowania statku jest zbędne?"}
{"_id": "455", "text": "Których członków rodziny funkcjonariusza uwzględnia się przy przydziale lokalu?"}
{"_id": "456", "text": "Kiedy ubezpieczyciel może odstąpić od umowy albo żądać zapłaty składki dodatkowej za zwiększone niebezbieczeństwo?"}
{"_id": "457", "text": "Kiedy ulegają przedawnieniu roszczenia z tytułu prawa do uposażenia?"}
{"_id": "458", "text": "Kiedy ulegają przedawnieniu roszczenia z tytułu prawa do uposażenia?"}
{"_id": "459", "text": "Których członków rodziny funkcjonariusza uwzględnia się przy przydziale lokalu?"}
{"_id": "460", "text": "Jakie instytucje są organami dochodzenia w sprawach o przestępstwa skarbowe i wykroczenia?"}
{"_id": "461", "text": "Jaki procent uprawnionych do głosowania musi wziąć udział w referendum, żeby było ono ważne?"}
{"_id": "462", "text": "W ciągu ilu dni od ogłoszenia wyników wyborów przez Państwową Komisję Wyborczą można wnieść protest?"}
{"_id": "463", "text": "Kiedy ulegają przedawnieniu roszczenia z tytułu prawa do uposażenia?"}
{"_id": "464", "text": "Kto wchodzi w skład komisji rewizyjnej powoływanej przez radę powiatu?"}
{"_id": "465", "text": "W jakich przypadkach na towary rolne dopuszczone do wolnego obiegu mogą być nałożone dodatkowe opłaty celne?"}
{"_id": "466", "text": "Jakie są zadania gmin w ramach prac związanych ze spisem?"}
{"_id": "467", "text": "Jaki procent uprawnionych do głosowania musi wziąć udział w referendum, żeby było ono ważne?"}
{"_id": "468", "text": "Kiedy do okresu zasiłkowego wlicza się okresy poprzedniej niezdolności do pracy, spowodowanej tą samą chorobą?"}
{"_id": "469", "text": "Co nazywamy wzorem przemysłowym?"}
{"_id": "470", "text": "Co obowiązany jest mieć przy sobie kierowca pojazdu samochodowego podczas przejazdu wykonywanego w ramach transportu drogowego?"}
{"_id": "471", "text": "Kogo minister właściwy do spraw transportu może upoważnić do wydawania zezwoleń zagranicznych?"}
{"_id": "472", "text": "Jakie są stawki kar za zniszczenie jednego metra kwadratowego terenu zieleni?"}
{"_id": "473", "text": "Jaki dzień jest Świętem Żandarmerii Wojskowej?"}
{"_id": "474", "text": "Kogo minister właściwy do spraw transportu może upoważnić do wydawania zezwoleń zagranicznych?"}
{"_id": "475", "text": "Jakie instytucje są organami dochodzenia w sprawach o przestępstwa skarbowe i wykroczenia?"}
{"_id": "476", "text": "Na jakich zasadach odbywają się przewozy wojsk obcych kolejami?"}
{"_id": "477", "text": "Jakie są zadania gmin w ramach prac związanych ze spisem?"}
{"_id": "478", "text": "Czyją własnością są zwierzęta łowne w stanie wolnym?"}
{"_id": "479", "text": "Jakie substancje słodzące mogą być stosowane przy produkcji wyrobów winiarskich?"}
{"_id": "480", "text": "Co jeśli dwie topografie są identyczne?"}
{"_id": "481", "text": "Kto posiada prawo odtwarzania zapisów telefonicznych?"}
{"_id": "482", "text": "Jaki bank może pełnić rolę reprezentanta?"}
{"_id": "483", "text": "Jakie role pełni wojewoda?"}
{"_id": "484", "text": "Jakie dane musi posiadać księga rachunkowa prowadzona elektronicznie?"}
{"_id": "485", "text": "Kiedy urząd skarbowy może obniżyć stawki ryczałtu osób duchownych?"}
{"_id": "486", "text": "Jakie są obowiązki wojewody?"}
{"_id": "487", "text": "Co musi zawierać wniosek złożony przez rzecznika dyscyplinarnego?"}
{"_id": "488", "text": "Co musi znajdować się w reklamie produktu korzystającego z energii?"}
{"_id": "489", "text": "Jakie są obowiązki zawodnika sportowego?"}
{"_id": "490", "text": "Jakie są obowiązki organów kontroli i rewizji?"}
{"_id": "491", "text": "Kiedy otwiera się księgi rachunkowe?"}
{"_id": "492", "text": "O czym należy pouczyć oskarżonego?"}
{"_id": "493", "text": "Czy spółki celowe z okazji Euro 2012 mogą być tworzone przez miasto Kraków?"}
{"_id": "494", "text": "Czy do wywozu meteorytu za granicę, potrzebna jest zgoda?"}
{"_id": "495", "text": "Kto może prowadzić dochodzenia?"}
{"_id": "496", "text": "Kiedy można pozbawić kogoś praw publicznych?"}
{"_id": "497", "text": "Czy wynagrodzenie kierowcy może zależeć od przejechanych kilometrów?"}
{"_id": "498", "text": "Kiedy można cofnąć zezwolenie na prowadzenie praktyki pielęgniarskiej?"}
{"_id": "499", "text": "Kto określa pracę komisji wyborczych?"}
{"_id": "500", "text": "Czy ścieki mogą zawierach DDT?"}
{"_id": "501", "text": "Z czego finansowany samorząd izby psychologów?"}
{"_id": "502", "text": "Jakie sa zadania Krajowego Administratora?"}
{"_id": "503", "text": "Jakie zadania ma kapitan statku w przypadku popełnienia przestępstwa?"}
{"_id": "504", "text": "Jakie są obowiązki kontrolowanego?"}
{"_id": "505", "text": "Co może zrobić prokurator gdy istnieją przesłanki o umorzenie postępowania?"}
{"_id": "506", "text": "Jakie są zadanie okręgowej komisji kwalifikacyjnej?"}
{"_id": "507", "text": "Czyje dane osobowe przetwarzają sądy okręgowe?"}
{"_id": "508", "text": "jakie przepisy stosuje się w przypadku wynalazku, na który nie udzielono jeszcze patentu?"}
{"_id": "509", "text": "W jakim terminie producent chmielu musi przekazać kopie umów do inspektora?"}
{"_id": "510", "text": "Co jeśli dwie topografie są identyczne?"}
{"_id": "511", "text": "Kto posiada prawo odtwarzania zapisów telefonicznych?"}
{"_id": "512", "text": "Jaki bank może pełnić rolę reprezentanta?"}
{"_id": "513", "text": "Jakie role pełni wojewoda?"}
{"_id": "514", "text": "Jakie role pełni wojewoda?"}
{"_id": "515", "text": "Jakie dane musi posiadać księga rachunkowa prowadzona elektronicznie?"}
{"_id": "516", "text": "Kiedy urząd skarbowy może obniżyć stawki ryczałtu osób duchownych?"}
{"_id": "517", "text": "Co musi znajdować się w reklamie produktu korzystającego z energii?"}
{"_id": "518", "text": "Co musi znajdować się w reklamie produktu korzystającego z energii?"}
{"_id": "519", "text": "Co musi znajdować się w reklamie produktu korzystającego z energii?"}
{"_id": "520", "text": "Jakie są obowiązki zawodnika sportowego?"}
{"_id": "521", "text": "Jakie są obowiązki organów kontroli i rewizji?"}
{"_id": "522", "text": "Jakie są obowiązki organów kontroli i rewizji?"}
{"_id": "523", "text": "Jakie są obowiązki organów kontroli i rewizji?"}
{"_id": "524", "text": "Kiedy otwiera się księgi rachunkowe?"}
{"_id": "525", "text": "O czym należy pouczyć oskarżonego?"}
{"_id": "526", "text": "O czym należy pouczyć oskarżonego?"}
{"_id": "527", "text": "O czym należy pouczyć oskarżonego?"}
{"_id": "528", "text": "Czy spółki celowe z okazji Euro 2012 mogą być tworzone przez miasto Kraków?"}
{"_id": "529", "text": "Kto może prowadzić dochodzenia?"}
{"_id": "530", "text": "Kiedy można pozbawić kogoś praw publicznych?"}
{"_id": "531", "text": "Czy wynagrodzenie kierowcy może zależeć od przejechanych kilometrów?"}
{"_id": "532", "text": "Czy wynagrodzenie kierowcy może zależeć od przejechanych kilometrów?"}
{"_id": "533", "text": "Kiedy można cofnąć zezwolenie na prowadzenie praktyki pielęgniarskiej?"}
{"_id": "534", "text": "Kto określa pracę komisji wyborczych?"}
{"_id": "535", "text": "Czy ścieki mogą zawierach DDT?"}
{"_id": "536", "text": "Z czego finansowany samorząd izby psychologów?"}
{"_id": "537", "text": "Jakie sa zadania Krajowego Administratora?"}
{"_id": "538", "text": "Jakie sa zadania Krajowego Administratora?"}
{"_id": "539", "text": "Jakie zadania ma kapitan statku w przypadku popełnienia przestępstwa?"}
{"_id": "540", "text": "Jakie są obowiązki kontrolowanego?"}
{"_id": "541", "text": "Jakie są obowiązki kontrolowanego?"}
{"_id": "542", "text": "Jakie są obowiązki kontrolowanego?"}
{"_id": "543", "text": "Jakie są obowiązki kontrolowanego?"}
{"_id": "544", "text": "Co może zrobić prokurator gdy istnieją przesłanki o umorzenie postępowania?"}
{"_id": "545", "text": "Co może zrobić prokurator gdy istnieją przesłanki o umorzenie postępowania?"}
{"_id": "546", "text": "Co może zrobić prokurator gdy istnieją przesłanki o umorzenie postępowania?"}
{"_id": "547", "text": "Jakie są zadanie okręgowej komisji kwalifikacyjnej?"}
{"_id": "548", "text": "Czyje dane osobowe przetwarzają sądy okręgowe?"}
{"_id": "549", "text": "jakie przepisy stosuje się w przypadku wynalazku, na który nie udzielono jeszcze patentu?"}
{"_id": "550", "text": "W jakim terminie producent chmielu musi przekazać kopie umów do inspektora?"}
{"_id": "551", "text": "Gdzie należy dokonać sprawdzenia, czy spełnione są wymagane warunki do uzyskania patentu?"}
{"_id": "552", "text": "Kto powołuje członków Kolegium?"}
{"_id": "553", "text": "Kto powołuje prezesa zarządu banku spółdzielczego?"}
{"_id": "554", "text": "W jakiej walucie prowadzi się księgi rachunkowe?"}
{"_id": "555", "text": "Przez kogo są wydawane przepisy techniczno-budowlane dotyczące autostrad?"}
{"_id": "556", "text": "Komu podlega Krajowy Urząd Pracy?"}
{"_id": "557", "text": "Komu podlega Najwyższa Izba Kontroli?"}
{"_id": "558", "text": "Kto ustala strukturę organizacyjną Naczelnego Sądu Administracyjnego?"}
{"_id": "559", "text": "Kto tworzy lokalną wspólnotę samorządową powiatu?"}
{"_id": "560", "text": "Jakie informacje nie mogą być zbierane w badaniach statystycznych z udziałem osób fizycznych jako obowiązek?"}
{"_id": "561", "text": "Kto jest naczelnym organem administracji rządowej w zakresie łowiectwa?"}
{"_id": "562", "text": "Kto określa wysokość wynagrodzeń dla członków Rady Ministrów?"}
{"_id": "563", "text": "Komu podlega szef Służby Cywilnej?"}
{"_id": "564", "text": "Co obejmują ubezpieczenia społeczne?"}
{"_id": "565", "text": "Co powinna zawierać umowa spółki jawnej?"}
{"_id": "566", "text": "Z ilu osób składa się rada nadzorcza banku spółdzielczego?"}
{"_id": "567", "text": "Kto określa sposób postępowania terenowych organów Państwowej Inspekcji Weterynaryjnej?"}
{"_id": "568", "text": "Ile wynosi składka na ubezpieczenie zdrowotne?"}
{"_id": "569", "text": "Kto jest naczelnym organem administracji rządowej właściwym w sprawach polityki energetycznej?"}
{"_id": "570", "text": "Na co mogą być przeznaczone środki publiczne?"}
{"_id": "571", "text": "Komu przysługuje emerytura wojskowa?"}
{"_id": "572", "text": "Kiedy stosuje się ustawę karną polską?"}
{"_id": "573", "text": "Gdzie wykonuje się karę ograniczenia wolności?"}
{"_id": "574", "text": "Kiedy przywóz towaru na polski obszar celny można uznać za nadmierny?"}
{"_id": "575", "text": "W jakich okolicznościach obwiniony musi mieć obrońcę przed sądem?"}
{"_id": "576", "text": "Jakie są rodzaje wiz?"}
{"_id": "577", "text": "Jaka jest minimalna wartość aktywów netto funduszu inwestycyjnego?"}
{"_id": "578", "text": "Ile trwa kadencja szefa służby cywilnej?"}
{"_id": "579", "text": "W jakich okolicznościach zezwolenie na wprowadzenie nawozu do obrotu podlega cofnięciu?"}
{"_id": "580", "text": "Ile wynosi przeciętne wynagrodzenie brutto prognozowane na 2004 rok?"}
{"_id": "581", "text": "Jakie dodatkowe oznaczenie powinna zawierać firma spółki?"}
{"_id": "582", "text": "Jakie dodatkowe oznaczenie powinna zawierać firma spółki?"}
{"_id": "583", "text": "Jakie dodatkowe oznaczenie powinna zawierać firma spółki?"}
{"_id": "584", "text": "Jakie dodatkowe oznaczenie powinna zawierać firma spółki?"}
{"_id": "585", "text": "Kto określa tryb udzielania pomocy przez organy samorządu terytorialnego?"}
{"_id": "586", "text": "W jakim przypadku można wydać orzeczenie surowsze niż uchylone?"}
{"_id": "587", "text": "W jakim przypadku można wydać orzeczenie surowsze niż uchylone?"}
{"_id": "588", "text": "Jakiej karze podlega osoba, która w lesie rozgarnia ściółkę?"}
{"_id": "589", "text": "O ile można maksymalnie pomniejszyć świadczenie dla bezrobotnego, któremu przyznano emeryturę lub rentę za okres, za który otrzymał zasiłek?"}
{"_id": "590", "text": "Jakie koszty sądowe pobiera się od żołnierza zawodowego w razie warunkowego umorzenia?"}
{"_id": "591", "text": "Jakiej karze podlega ten, kto zawiadamia o przestępstwie, którego nie popełniono?"}
{"_id": "592", "text": "Po jakim czasie można ponownie wnioskować o udzielenie koncesji po jej cofnięciu?"}
{"_id": "593", "text": "Ile maksymalnie mogą trwać negocjacje?"}
{"_id": "594", "text": "Jakie pytania może zadawać oskarżony podczas rozprawy?"}
{"_id": "595", "text": "Kto i w jakim terminie może wnieść sprzeciw od decyzji Urzędu Patentowego?"}
{"_id": "596", "text": "Jakie opłaty wiążą się z przeniesieniem własności świadectwa rekompensacyjnego?"}
{"_id": "597", "text": "Na jakich glebach nie można stosować nawozów naturalnych?"}
{"_id": "598", "text": "Kto publikuje opracowanie statystyczne na temat wyników głosowania i wyborów?"}
{"_id": "599", "text": "Kto publikuje opracowanie statystyczne na temat wyników głosowania i wyborów?"}
{"_id": "600", "text": "Jaki procent przychodów stanowią odpisy z funduszu składkowego?"}
{"_id": "601", "text": "Kto wchodzi w skład Rady Służby Cywilnej?"}
{"_id": "602", "text": "Ile głosów można oddać na jednego kandydata?"}
{"_id": "603", "text": "Ile głosów można oddać na jednego kandydata?"}
{"_id": "604", "text": "Ile głosów można oddać na jednego kandydata?"}
{"_id": "605", "text": "Co uwzględnia wymiar czasu pracy obowiązujący pracownika?"}
{"_id": "606", "text": "Jakie obowiązki mają Żołnierze Żandarmerii Wojskowej w toku wykonywania czynności?"}
{"_id": "607", "text": "Jakiej karze podlega ten, kto nie zwraca sprzedawcy opakowania po substancji toksycznej?"}
{"_id": "608", "text": "Ile dni jest na złożenie wniosku o uzupełnienie materiałów zebranych w postępowaniu dyscyplinarnym?"}
{"_id": "609", "text": "Na jakich zasadach otrzymuje odszkodowanie funkcjonariusz, który doznał uszczerbku na zdrowiu?"}
{"_id": "610", "text": "Na jakich zasadach otrzymuje odszkodowanie funkcjonariusz, który doznał uszczerbku na zdrowiu?"}
{"_id": "611", "text": "Jakie przepisy stosuje się do obowiązków wynikających z decyzji organów inspekcji?"}
{"_id": "612", "text": "Jakie przepisy stosuje się do obowiązków wynikających z decyzji organów inspekcji?"}
{"_id": "613", "text": "W jakim terminie organy państwowe podejmują czynności po przeprowadzeniu referendum?"}
{"_id": "614", "text": "Kto i w jakiej drodze określa zasady kontroli płatników składek?"}
{"_id": "615", "text": "Jakie dane wpisuje się w ewidencjach paszportowych?"}
{"_id": "616", "text": "Jakie dane wpisuje się w ewidencjach paszportowych?"}
{"_id": "617", "text": "Kto reprezentuje Skarb Państwa w sprawach wytoczonych przeciwko niemu?"}
{"_id": "618", "text": "Ile maksymalnie może pracować kierowca w tygodniu?"}
{"_id": "619", "text": "Ile maksymalnie może pracować kierowca w tygodniu?"}
{"_id": "620", "text": "Ile maksymalnie może pracować kierowca w tygodniu?"}
{"_id": "621", "text": "Kto nie może być obecny przy przesłuchaniu świadka?"}
{"_id": "622", "text": "Kto nie może być obecny przy przesłuchaniu świadka?"}
{"_id": "623", "text": "Czy Minister Zdrowia może określić inne choroby zakaźne zwierząt podlegające zwalczaniu na obszarze całego kraju?"}
{"_id": "624", "text": "Czy naczelnicy urzędów skarbowych składają Ministrowi Zdrowia półroczne sprawozdania zawierające informacje o liczbie wszczętych w danym półroczu postępowań podatkowych oraz karnych skarbowych?"}
{"_id": "625", "text": "Czy zarząd może być jednoosobowy?"}
{"_id": "626", "text": "Czy osoby wykonujące prace związane z przygotowaniem spisu powinny przestrzegać tajemnicę statystyczną?"}
{"_id": "627", "text": "Jakiej komisji Minister właściwy do spraw administracji publicznej przekazuje informacje i sprawozdania dotyczące tworzenia i funkcjonowania infrastruktury?"}
{"_id": "628", "text": "Jakiej karze podlega żołnierz, który znęca się psychicznie nad podwładnym?"}
{"_id": "629", "text": "Czy dane osobowe cudzoziemców, którym nadano status uchodźcy, udzielono azylu, oraz cudzoziemców ubiegających się o nadanie statusu uchodźcy lub o udzielenie azylu podlegają ochronie?"}
{"_id": "630", "text": "Czy naruszenie nietykalności cielesnej funkcjonariusza publicznego może skutkować karą pozbawienia wolności na 25 lat?"}
{"_id": "631", "text": "Czy kuratorowi zawodowemu przysługuje prawo do podnoszenia kwalifikacji zawodowych w formie kształcenia zdalnego?"}
{"_id": "632", "text": "Czy za uratowanie frachtu oraz opłat za przewóz pasażerów i bagażu należy się wynagrodzenie?"}
{"_id": "633", "text": "Co jest wymagane do przekształcenia spółki?"}
{"_id": "634", "text": "Czy umowa spółki może zwolnić wspólnika od udziału w stratach?"}
{"_id": "635", "text": "Czy statek rybacki, który zatonął, jest wykreślany z ewidencji?"}
{"_id": "636", "text": "Czy Prezydent Rzeczypospolitej Polskiej może ratyfikować umowę wielostronną w sprawie opłat trasowych, sporządzoną w Brukseli dnia 12 lutego 1981 r.?"}
{"_id": "637", "text": "Czy w okresie od zakończenia kampanii wyborczej do zakończenia głosowania można podawać do wiadomości publicznej wyniki przedwyborczych badań opinii publicznej dotyczących przewidywanych zachowań wyborczych?"}
{"_id": "638", "text": "Czy istnieje wyższy organ okręgowej izby niż okręgowy zjazd izby?"}
{"_id": "639", "text": "Czy kuratorowi zawodowemu można udzielić płatnego urlopu dla poratowania zdrowia, w wymiarze 24 miesięcy?"}
{"_id": "640", "text": "Kto odpowiada całym swoim majątkiem za wynikające ze zobowiązań podatkowych podatki?"}
{"_id": "641", "text": "Z czego składa się Krajowy Rejestr Sądowy?"}
{"_id": "642", "text": "Z czego pokrywane są wydatki Rady Spółdzielczej?"}
{"_id": "643", "text": "Na czym polega wspieranie procesu modernizacji technicznej Sił Zbrojnych Rzeczypospolitej Polskiej?"}
{"_id": "644", "text": "Czy zgromadzenie przedstawicieli może podjąć uchwałę w obecności mniej, niż połowy członków?"}
{"_id": "645", "text": "Kto ponosi odpowiedzialność dyscyplinarną za przewinienia dyscyplinarne popełnione podczas lub w związku z wykonywaniem czynności prokuratora albo asesora?"}
{"_id": "646", "text": "Czy działalność zawodowa, wykonywana w sposób zorganizowany i ciągły, jest działalnością gospodarczą?"}
{"_id": "647", "text": "Wobec kogo frachtujący odpowiada za szkody spowodowane niedokładnym lub nieprawdziwym oświadczeniem dotyczącym rodzaju lub właściwości ładunku?"}
{"_id": "648", "text": "Czy na wniosek pracownika może być do niego stosowany system czasu pracy, w którym praca jest świadczona wyłącznie w piątki, soboty, niedziele i święta?"}
{"_id": "649", "text": "Czy w czasie ogłaszania wyroku wszyscy obecni powinni stać?"}
{"_id": "650", "text": "Czym jest spółka partnerska?"}
{"_id": "651", "text": "Czy zarząd może być jednoosobowy?"}
{"_id": "652", "text": "Czy osoby wykonujące prace związane z przygotowaniem spisu powinny przestrzegać tajemnicę statystyczną?"}
{"_id": "653", "text": "W jakim terminie Prezes Urzędu Mieszkalnictwa i Rozwoju Miast musi ogłosić w Dzienniku Urzędowym Rzeczypospolitej Polskiej średnie podstawowych dochodów podatkowych gmin za dany rok w przeliczeniu na 1 mieszkańca?"}
{"_id": "654", "text": "W jakim terminie Prezes Urzędu Mieszkalnictwa i Rozwoju Miast musi ogłosić w Dzienniku Urzędowym Rzeczypospolitej Polskiej średnie podstawowych dochodów podatkowych gmin za dany rok w przeliczeniu na 1 mieszkańca?"}
{"_id": "655", "text": "Czy statek rybacki, który zatonął, jest wykreślany z ewidencji?"}
{"_id": "656", "text": "Czy w okresie od zakończenia kampanii wyborczej do zakończenia głosowania można podawać do wiadomości publicznej wyniki przedwyborczych badań opinii publicznej dotyczących przewidywanych zachowań wyborczych?"}
{"_id": "657", "text": "Czy w okresie od zakończenia kampanii wyborczej do zakończenia głosowania można podawać do wiadomości publicznej wyniki przedwyborczych badań opinii publicznej dotyczących przewidywanych zachowań wyborczych?"}
{"_id": "658", "text": "Czy zarząd może być jednoosobowy?"}
{"_id": "659", "text": "Czy zarząd może być jednoosobowy?"}
{"_id": "660", "text": "Kto ma zgodę na dokonanie ratyfikacji Umowy między Rzecząpospolitą Polską a Mongolią o pomocy prawnej i stosunkach prawnych w sprawach cywilnych"}
{"_id": "661", "text": "Czego zakazuje się wykrzysytwać do żywienia ludzi lub do produkcji innych środków spożywczych?"}
{"_id": "662", "text": "Kto ponosi odpowiedzialność w razie wyrządzenia nieumyślnie szkody przez kilku funkcjonariuszy?"}
{"_id": "663", "text": "Jakie zwierzęta podlegają rejestracji?"}
{"_id": "664", "text": "Pod jakim warunkiem zezwolenia na prowadzenie działalności gospodarczej zachowują ważność?"}
{"_id": "665", "text": "W jakim zakresie stosuje się również te przepisy?"}
{"_id": "666", "text": "Czy podmiotowi przysługuje prawo do wniesienia odwołania lub zażalenia.?"}
{"_id": "667", "text": "Czy osoba, która cieszy się nieposzlakowaną opinią. może zostać urzędnikiem?"}
{"_id": "668", "text": "Czy w każdej gminie znajduje się wojewódzka biblioteka publiczna?"}
{"_id": "669", "text": "Co to obwód łowiecki leśny?"}
{"_id": "670", "text": "Na co przeznacza się Środki Funduszu Rozwoju?"}
{"_id": "671", "text": "Co robi się z każdorazowym wypadkiem zastosowania tymczasowego aresztowania wobec obywatela państwa obcego?"}
{"_id": "672", "text": "Czy udział prokuratora w rozprawie wyłącza obowiązek udziału finansowego organu dochodzenia lub jego przedstawiciela w charakterze oskarżyciela publicznego?"}
{"_id": "673", "text": "Kiedy Minister Sprawiedliwości zwraca się do właściwego organu państwa obcego?"}
{"_id": "674", "text": "W jakich przypadkach odmawia się powtrnego wydania pozwolenia na połowy organizmów morskich w celach naukowo-badawczych?"}
{"_id": "675", "text": "Kto sprawuje nadzór nad Akademią?"}
{"_id": "676", "text": "Czy urzędnik służby cywilnej przy wykonywaniu obowiązków służbowych może kierować się swoimi przekonaniami politycznymi?"}
{"_id": "677", "text": "Nad czym badania naukowe prowadzi Instytut Pamięci?"}
{"_id": "678", "text": "Gdzie wpisuje się osoby, którym przysługuje prawo wybierania?"}
{"_id": "679", "text": "Co należy uwzględnić przy ocenie, czy oznaczenie ma dostateczne znamiona odróżniające?"}
{"_id": "680", "text": "Ile trwa kara ograniczenia wolności jeżeli ustawa nie stanowi inaczej?"}
{"_id": "681", "text": "Jak udziela się pochwał?"}
{"_id": "682", "text": "Co należy rozumieć przez uposażenie, o którym mowa w ust. 1?"}
{"_id": "683", "text": "Kto jest przedstawicielem Rady Ministrów w województwie?"}
{"_id": "684", "text": "Kiedy zostaną wydane akty wykonawcze o których mowa w art. 21 ust. 2?"}
{"_id": "685", "text": "Co stosuje się w zakresie nie uregulowanym w art. 139-141 do egzekucji ze świadczeń pieniężnych?"}
{"_id": "686", "text": "Kto może być zatrudniony przy wykonywaniu w aptece czynności fachowych?"}
{"_id": "687", "text": "Czemu równa jest cena emisyjna certyfikatów inwestycyjnych drugiej i następnych emisji?"}
{"_id": "688", "text": "Ile wynosi łączna kwota wpłat gmin, o której mowa w art. 23 ustawy z dnia 26 listopada 1998 r.?"}
{"_id": "689", "text": "Jak informacja publiczna może być udostępniana?"}
{"_id": "690", "text": "Czy osoba która ma obywatelstwo polskie może być Funkcjonariuszem Inspekcji Celnej?"}
{"_id": "691", "text": "Czy osoba która ma obywatelstwo polskie może być Funkcjonariuszem Inspekcji Celnej?"}
{"_id": "692", "text": "Kto sprawuje nadzór na działalnością wojewody?"}
{"_id": "693", "text": "Ilu radnych wybiera się w jednym okręgu wyborczym?"}
{"_id": "694", "text": "Ilu radnych wybiera się w jednym okręgu wyborczym?"}
{"_id": "695", "text": "Kiedy artykuły spożywcze przywiezione z zagranicy mogą być objętą procedurą dopuszczenia do obrotu?"}
{"_id": "696", "text": "Czy specjalne zezwolenie połowowe zawiera wykształcenie armatora statku rybackiego?"}
{"_id": "697", "text": "Czy specjalne zezwolenie połowowe zawiera wykształcenie armatora statku rybackiego?"}
{"_id": "698", "text": "Czy specjalne zezwolenie połowowe zawiera wykształcenie armatora statku rybackiego?"}
{"_id": "699", "text": "Kto może uczestniczyć w zajęciach prowadzonych w klubie dziecięcym?"}
{"_id": "700", "text": "Jaki Kodeks reguluje stosunki prawne związane z żeglugą morską?"}
{"_id": "701", "text": "Czy zażalenie wstrzymuje wykonanie zaskarżonego rozstrzygnięcia?"}
{"_id": "702", "text": "Jak nazywa się jednostka współpracy administracyjnej w dziedzinie akcyzy?"}
{"_id": "703", "text": "Kiedy armator nie ponosi odpowiedzialności?"}
{"_id": "704", "text": "Kto sprawuje nadzór nad Akademią?"}
{"_id": "705", "text": "Kto sprawuje nadzór nad Akademią?"}
{"_id": "706", "text": "Czy dyrektorem żłobka może być osoba posiadająca wykształcenie podstawowe?"}
{"_id": "707", "text": "Co to prace w szczególnych warunkach?"}
{"_id": "708", "text": "Czy składki płacone przez pracodawców należą do dochodów Funduszu?"}
{"_id": "709", "text": "Czy prawa i obowiązki członków izby określają statut izby?"}
{"_id": "710", "text": "Kto podpisuje protokół przesłuchania świadka?"}
{"_id": "711", "text": "Kto podpisuje protokół przesłuchania świadka?"}
{"_id": "712", "text": "Kto podpisuje protokół przesłuchania świadka?"}
{"_id": "713", "text": "Kto określa określa sposób postępowania terenowych organów Państwowej Inspekcji Weterynaryjnej?"}
{"_id": "714", "text": "Ile wynosiła stopa procentowa składek na ubezpieczenie wypadkowe za okres od 1 stycznia do 31 grudnia 1999."}
{"_id": "715", "text": "Co tworzy Fundusz Ekspercki?"}
{"_id": "716", "text": "Czy kościelne osoby prawne mają prawo do zbierania ofiar na cele naukowe?"}
{"_id": "717", "text": "Po ilu dniach zwalnia się tymczasowo aresztowanego?"}
{"_id": "718", "text": "Kiedy Główny Inspektor Farmaceutyczny odmawia udzielenie zezwolenia na prowadzenie hurtowni farmaceutyczne?"}
{"_id": "719", "text": "Kiedy pismo uważa się za doręczone?"}
{"_id": "720", "text": "Kiedy pismo uważa się za doręczone?"}
{"_id": "721", "text": "Kiedy prawo do świadczeń ustaje?"}
{"_id": "722", "text": "Co należy do zadań inspekcji?"}
{"_id": "723", "text": "Jakiej karze podlega funkcjonariusz publiczny stosujący przemoc nad inną osobą w celu uzyskania zeznań?"}
{"_id": "724", "text": "Czy osoba nie znająca żadnego języka obcego może się ubiegać o mianowanie w służbie cywilnej?"}
{"_id": "725", "text": "Kto sprawuje nadzór nad Uniwersytetem?"}
{"_id": "726", "text": "Kto sprawuje nadzór nad Uniwersytetem?"}
{"_id": "727", "text": "Co jest zadaniem kuratora sądowego, a także innych osób, stowarzyszeń, organizacji i instytucji wykonujących dozór?"}
{"_id": "728", "text": "Co jest zadaniem kuratora sądowego, a także innych osób, stowarzyszeń, organizacji i instytucji wykonujących dozór?"}
{"_id": "729", "text": "Co jest zadaniem kuratora sądowego, a także innych osób, stowarzyszeń, organizacji i instytucji wykonujących dozór?"}
{"_id": "730", "text": "Co jest zadaniem kuratora sądowego, a także innych osób, stowarzyszeń, organizacji i instytucji wykonujących dozór?"}
{"_id": "731", "text": "Jakie działania może powziąć sąd, aby nadzwyczajnie złagodziić karę?"}
{"_id": "732", "text": "Jakie działania może powziąć sąd, aby nadzwyczajnie złagodziić karę?"}
{"_id": "733", "text": "Jakie działania może powziąć sąd, aby nadzwyczajnie złagodziić karę?"}
{"_id": "734", "text": "Jakie działania może powziąć sąd, aby nadzwyczajnie złagodziić karę?"}
{"_id": "735", "text": "Wobec kogo sąd może orzec obniżenie stopnia wojskowego albo degradację?"}
{"_id": "736", "text": "Wobec kogo sąd może orzec obniżenie stopnia wojskowego albo degradację?"}
{"_id": "737", "text": "Wobec kogo sąd może orzec obniżenie stopnia wojskowego albo degradację?"}
{"_id": "738", "text": "Wobec kogo sąd może orzec obniżenie stopnia wojskowego albo degradację?"}
{"_id": "739", "text": "Na jakiej podstawie przepisy ustawy nie dotyczą użycia Sił Zbrojnych poza granicami Rzeczypospolitej Polskiej?"}
{"_id": "740", "text": "Na jakiej podstawie przepisy ustawy nie dotyczą użycia Sił Zbrojnych poza granicami Rzeczypospolitej Polskiej?"}
{"_id": "741", "text": "Na jakiej podstawie przepisy ustawy nie dotyczą użycia Sił Zbrojnych poza granicami Rzeczypospolitej Polskiej?"}
{"_id": "742", "text": "Na jakiej podstawie przepisy ustawy nie dotyczą użycia Sił Zbrojnych poza granicami Rzeczypospolitej Polskiej?"}
{"_id": "743", "text": "Kto jest stroną w postępowaniu dyscyplinarnym?"}
{"_id": "744", "text": "Kto jest stroną w postępowaniu dyscyplinarnym?"}
{"_id": "745", "text": "Kto jest stroną w postępowaniu dyscyplinarnym?"}
{"_id": "746", "text": "Kto jest stroną w postępowaniu dyscyplinarnym?"}
{"_id": "747", "text": "Czego nie wolno wykorzystywać do żywienia ludzi oraz do produkcji?"}
{"_id": "748", "text": "Czego nie wolno wykorzystywać do żywienia ludzi oraz do produkcji?"}
{"_id": "749", "text": "Czego nie wolno wykorzystywać do żywienia ludzi oraz do produkcji?"}
{"_id": "750", "text": "Czego nie wolno wykorzystywać do żywienia ludzi oraz do produkcji?"}
{"_id": "751", "text": "Co powinno zawierać oświadczenie żołnierza o swoim stanie majątkowym?"}
{"_id": "752", "text": "Co powinno zawierać oświadczenie żołnierza o swoim stanie majątkowym?"}
{"_id": "753", "text": "Co powinno zawierać oświadczenie żołnierza o swoim stanie majątkowym?"}
{"_id": "754", "text": "Co powinno zawierać oświadczenie żołnierza o swoim stanie majątkowym?"}
{"_id": "755", "text": "W jaki sposób wyniki rolniczych badań rynkowych są udostępniane i rozpowszechniane?"}
{"_id": "756", "text": "W jaki sposób wyniki rolniczych badań rynkowych są udostępniane i rozpowszechniane?"}
{"_id": "757", "text": "W jaki sposób wyniki rolniczych badań rynkowych są udostępniane i rozpowszechniane?"}
{"_id": "758", "text": "W jaki sposób wyniki rolniczych badań rynkowych są udostępniane i rozpowszechniane?"}
{"_id": "759", "text": "Jakiej spółce może zostać udzielona koncesja?"}
{"_id": "760", "text": "Jakiej spółce może zostać udzielona koncesja?"}
{"_id": "761", "text": "Jakiej spółce może zostać udzielona koncesja?"}
{"_id": "762", "text": "Jakiej spółce może zostać udzielona koncesja?"}
{"_id": "763", "text": "W jakiej sytuacji osobie niezdolnej do pracy nie przysługuje zasiłek chorobowy za okres po ustaniu tytułu ubezpieczenia chorobowego?"}
{"_id": "764", "text": "W jakiej sytuacji osobie niezdolnej do pracy nie przysługuje zasiłek chorobowy za okres po ustaniu tytułu ubezpieczenia chorobowego?"}
{"_id": "765", "text": "W jakiej sytuacji osobie niezdolnej do pracy nie przysługuje zasiłek chorobowy za okres po ustaniu tytułu ubezpieczenia chorobowego?"}
{"_id": "766", "text": "W jakiej sytuacji osobie niezdolnej do pracy nie przysługuje zasiłek chorobowy za okres po ustaniu tytułu ubezpieczenia chorobowego?"}
{"_id": "767", "text": "Co należy do zadań Krajowej Rady Kuratorów?"}
{"_id": "768", "text": "Co należy do zadań Krajowej Rady Kuratorów?"}
{"_id": "769", "text": "Co należy do zadań Krajowej Rady Kuratorów?"}
{"_id": "770", "text": "Co należy do zadań Krajowej Rady Kuratorów?"}
{"_id": "771", "text": "Jakiej karze podlega osoba, która przywłaszcza sobie cudzą rzecz ruchomą lub prawo majątkowe?"}
{"_id": "772", "text": "Jakiej karze podlega osoba, która przywłaszcza sobie cudzą rzecz ruchomą lub prawo majątkowe?"}
{"_id": "773", "text": "Jakiej karze podlega osoba, która przywłaszcza sobie cudzą rzecz ruchomą lub prawo majątkowe?"}
{"_id": "774", "text": "Jakiej karze podlega osoba, która przywłaszcza sobie cudzą rzecz ruchomą lub prawo majątkowe?"}
{"_id": "775", "text": "Na jakich zasadach Trybunał Konstytucyjny rozpoznaje Wnioski o stwierdzenie zgodności z Konstytucją celów partii politycznych, które są określone w ich statucie lub w programie?"}
{"_id": "776", "text": "Na jakich zasadach Trybunał Konstytucyjny rozpoznaje Wnioski o stwierdzenie zgodności z Konstytucją celów partii politycznych, które są określone w ich statucie lub w programie?"}
{"_id": "777", "text": "Na jakich zasadach Trybunał Konstytucyjny rozpoznaje Wnioski o stwierdzenie zgodności z Konstytucją celów partii politycznych, które są określone w ich statucie lub w programie?"}
{"_id": "778", "text": "Na jakich zasadach Trybunał Konstytucyjny rozpoznaje Wnioski o stwierdzenie zgodności z Konstytucją celów partii politycznych, które są określone w ich statucie lub w programie?"}
{"_id": "779", "text": "Co określa statut funduszu inwestycyjnego?"}
{"_id": "780", "text": "Co określa statut funduszu inwestycyjnego?"}
{"_id": "781", "text": "Co określa statut funduszu inwestycyjnego?"}
{"_id": "782", "text": "Co określa statut funduszu inwestycyjnego?"}
{"_id": "783", "text": "Kto udziela pełnomocnictwa w przypadku, gdy jest ono wymagane do podpisania umowy międzynarodowej?"}
{"_id": "784", "text": "Kto udziela pełnomocnictwa w przypadku, gdy jest ono wymagane do podpisania umowy międzynarodowej?"}
{"_id": "785", "text": "Kto udziela pełnomocnictwa w przypadku, gdy jest ono wymagane do podpisania umowy międzynarodowej?"}
{"_id": "786", "text": "Kto udziela pełnomocnictwa w przypadku, gdy jest ono wymagane do podpisania umowy międzynarodowej?"}
{"_id": "787", "text": "Do czego jest zobowiązany żołnierz, który jest odpowiedzialny za szkodę wyrządzoną nieumyślnie?"}
{"_id": "788", "text": "Do czego jest zobowiązany żołnierz, który jest odpowiedzialny za szkodę wyrządzoną nieumyślnie?"}
{"_id": "789", "text": "Do czego jest zobowiązany żołnierz, który jest odpowiedzialny za szkodę wyrządzoną nieumyślnie?"}
{"_id": "790", "text": "Do czego jest zobowiązany żołnierz, który jest odpowiedzialny za szkodę wyrządzoną nieumyślnie?"}
{"_id": "791", "text": "Jakiej karze podlega osoba, która wykracza przeciwko obowiązkowi wpisu statku do rejestru?"}
{"_id": "792", "text": "Jakiej karze podlega osoba, która wykracza przeciwko obowiązkowi wpisu statku do rejestru?"}
{"_id": "793", "text": "Jakiej karze podlega osoba, która wykracza przeciwko obowiązkowi wpisu statku do rejestru?"}
{"_id": "794", "text": "Jakiej karze podlega osoba, która wykracza przeciwko obowiązkowi wpisu statku do rejestru?"}
{"_id": "795", "text": "Jaki warunek musi być spełniony, aby zabezpieczenie akcyzowe mogło zostać zwrócone?"}
{"_id": "796", "text": "Jaki warunek musi być spełniony, aby zabezpieczenie akcyzowe mogło zostać zwrócone?"}
{"_id": "797", "text": "Jaki warunek musi być spełniony, aby zabezpieczenie akcyzowe mogło zostać zwrócone?"}
{"_id": "798", "text": "Jaki warunek musi być spełniony, aby zabezpieczenie akcyzowe mogło zostać zwrócone?"}
{"_id": "799", "text": "Kiedy przedawnia się roszczenie o naprawienie szkody?"}
{"_id": "800", "text": "Kiedy przedawnia się roszczenie o naprawienie szkody?"}
{"_id": "801", "text": "Kiedy przedawnia się roszczenie o naprawienie szkody?"}
{"_id": "802", "text": "Kiedy przedawnia się roszczenie o naprawienie szkody?"}
{"_id": "803", "text": "Do ilu spisów może być wpisany wyborca?"}
{"_id": "804", "text": "Do ilu spisów może być wpisany wyborca?"}
{"_id": "805", "text": "Do ilu spisów może być wpisany wyborca?"}
{"_id": "806", "text": "Do ilu spisów może być wpisany wyborca?"}
{"_id": "807", "text": "W jakim stopniu kwoty opłat za czynności egzekucyjne ulegają podwyższaniu?"}
{"_id": "808", "text": "W jakim stopniu kwoty opłat za czynności egzekucyjne ulegają podwyższaniu?"}
{"_id": "809", "text": "W jakim stopniu kwoty opłat za czynności egzekucyjne ulegają podwyższaniu?"}
{"_id": "810", "text": "W jakim stopniu kwoty opłat za czynności egzekucyjne ulegają podwyższaniu?"}
{"_id": "811", "text": "Kto sprawuje nadzór nad działalnością Narodowego Funduszu?"}
{"_id": "812", "text": "Kto sprawuje nadzór nad działalnością Narodowego Funduszu?"}
{"_id": "813", "text": "Kto sprawuje nadzór nad działalnością Narodowego Funduszu?"}
{"_id": "814", "text": "Kto sprawuje nadzór nad działalnością Narodowego Funduszu?"}
{"_id": "815", "text": "Co podlega zaspokojeniu ze środków Funduszu?"}
{"_id": "816", "text": "Co podlega zaspokojeniu ze środków Funduszu?"}
{"_id": "817", "text": "Co podlega zaspokojeniu ze środków Funduszu?"}
{"_id": "818", "text": "Co podlega zaspokojeniu ze środków Funduszu?"}
{"_id": "819", "text": "Kto jest uprawniony do wprowadzania danych do bazy danych systemu informatycznego oraz do dokonywania zmian w bazie danych tego systemu?"}
{"_id": "820", "text": "Kto jest uprawniony do wprowadzania danych do bazy danych systemu informatycznego oraz do dokonywania zmian w bazie danych tego systemu?"}
{"_id": "821", "text": "Kto jest uprawniony do wprowadzania danych do bazy danych systemu informatycznego oraz do dokonywania zmian w bazie danych tego systemu?"}
{"_id": "822", "text": "Kto jest uprawniony do wprowadzania danych do bazy danych systemu informatycznego oraz do dokonywania zmian w bazie danych tego systemu?"}
{"_id": "823", "text": "Co grozi osobie, która prowadzi obrót detaliczny produktami leczniczymi weterynaryjnymi wydawanymi bez przepisu lekarza?"}
{"_id": "824", "text": "Co grozi osobie, która prowadzi obrót detaliczny produktami leczniczymi weterynaryjnymi wydawanymi bez przepisu lekarza?"}
{"_id": "825", "text": "Co grozi osobie, która prowadzi obrót detaliczny produktami leczniczymi weterynaryjnymi wydawanymi bez przepisu lekarza?"}
{"_id": "826", "text": "Co grozi osobie, która prowadzi obrót detaliczny produktami leczniczymi weterynaryjnymi wydawanymi bez przepisu lekarza?"}
{"_id": "827", "text": "Jaki organ dokonuje wymiaru i poboru opłaty celnej dodatkowej?"}
{"_id": "828", "text": "Jaki organ dokonuje wymiaru i poboru opłaty celnej dodatkowej?"}
{"_id": "829", "text": "Jaki organ dokonuje wymiaru i poboru opłaty celnej dodatkowej?"}
{"_id": "830", "text": "Jaki organ dokonuje wymiaru i poboru opłaty celnej dodatkowej?"}
{"_id": "831", "text": "Jakich czynnosi może dokonywać Przewodniczący Komitetu w ramach nadzoru?"}
{"_id": "832", "text": "Jakich czynnosi może dokonywać Przewodniczący Komitetu w ramach nadzoru?"}
{"_id": "833", "text": "Jakich czynnosi może dokonywać Przewodniczący Komitetu w ramach nadzoru?"}
{"_id": "834", "text": "Jakich czynnosi może dokonywać Przewodniczący Komitetu w ramach nadzoru?"}
{"_id": "835", "text": "Co jest podstawą do ogłoszenia aktów normatywnych i innych aktów prawnych?"}
{"_id": "836", "text": "Co jest podstawą do ogłoszenia aktów normatywnych i innych aktów prawnych?"}
{"_id": "837", "text": "Co jest podstawą do ogłoszenia aktów normatywnych i innych aktów prawnych?"}
{"_id": "838", "text": "Co jest podstawą do ogłoszenia aktów normatywnych i innych aktów prawnych?"}
{"_id": "839", "text": "Co jest celem łowiectwa?"}
{"_id": "840", "text": "Co jest celem łowiectwa?"}
{"_id": "841", "text": "Co jest celem łowiectwa?"}
{"_id": "842", "text": "Co jest celem łowiectwa?"}
{"_id": "843", "text": "Co jest jednostką organizacyjną samorządu?"}
{"_id": "844", "text": "Co jest jednostką organizacyjną samorządu?"}
{"_id": "845", "text": "Co jest jednostką organizacyjną samorządu?"}
{"_id": "846", "text": "Co jest jednostką organizacyjną samorządu?"}
{"_id": "847", "text": "Co reguluje kodeks morski?"}
{"_id": "848", "text": "Co należy zrobić z zyskiem pozostającym w dyspozycji instytucji gospodarki budżetowej?"}
{"_id": "849", "text": "Co należy uczynić jeżeli dowody nie są wystarczające w do rozstrzygnięcia powództwa cywilnego?"}
{"_id": "850", "text": "Kiedy może wygasnąć mandat posła?"}
{"_id": "851", "text": "Kto ma za zadanie wybierać przedstawiciela do rady nadzorczej regionalnej kasy?"}
{"_id": "852", "text": "Co zawiera rejestr producentów i importerów?"}
{"_id": "853", "text": "Jakie przepisy są używane do decyzji o wysokości opłat za ponowne wykorzystywanie informacji sektora publicznego? "}
{"_id": "854", "text": "Czy wybory do rad powiatów i sejmików są tajne?"}
{"_id": "855", "text": "Co musi zrobić kapitan w przypadku zgonu na statku?"}
{"_id": "856", "text": "Czy w trakcie zleceń wykonywanych podczas zabiegów ratujących życie pacjenta pielęgniarka musi postępować zgodnie z zleceniami w dokumentacji medycznej?"}
{"_id": "857", "text": "Kto jest stroną postępowania?"}
{"_id": "858", "text": "Kiedy organ celny może odstąpić od wymogu składania deklaracji skróconej?"}
{"_id": "859", "text": "Do kogo można się odwołać od decyzji o ustaleniu lokalizacji Euro 2012?"}
{"_id": "860", "text": "Spośród kogo jest wybierana rada zrzeszenia banków spółdzielczych?"}
{"_id": "861", "text": "Jaki artykuł stosowany jest do szkód wyrządzonych przez wojska obce?"}
{"_id": "862", "text": "Jaką karę daje się za więcej niż jedno wykroczenie"}
{"_id": "863", "text": "Kto ustala prawa i obowiązki rzeczników dyscypliny finansów publicznych?"}
{"_id": "864", "text": "Co należy zrobić jeśli jednostka otrzymała informacje o zdarzeniach dotyczących lat ubiegłych?"}
{"_id": "865", "text": "Co zalicza się do okresu przestawiania gospodarstwa rolnego na produkcję metodami ekologicznymi?"}
{"_id": "866", "text": "Do kiedy przedsiębiorcy muszą wstrzymać się od dokonania koncentracji?"}
{"_id": "867", "text": "Jakie obowiązki. zyskali komendanci komisariatów w 1999 roku?"}
{"_id": "868", "text": "Kto jest odpowiedzialny za uzgadnianie zakresu i szczegółowości wymaganych informacji w prognozie oddziaływania na środowisko?"}
{"_id": "869", "text": "Jaka jest maksymalna wysokość wsparcia finansowego przy produkcji utworu audiowizualnego?"}
{"_id": "870", "text": "Co jest wymagane oprócz zgody na zamknięte użycie GMO?"}
{"_id": "871", "text": "Czy maklerzy giełd towarowych są zobowiązani do zachowania tajemnicy zawodowej?"}
{"_id": "872", "text": "Kto może być inspektorem dozoru jądrowego?"}
{"_id": "873", "text": "Co należy do zadań żłobka i klubu dziecięcego?"}
{"_id": "874", "text": "Kiedy wygasa członkostwo w Radzie Służby Cywilnej?"}
{"_id": "875", "text": "Jakie organy należą do spółki wodnej?"}
{"_id": "876", "text": "Kto prowadzi rejestr związków?"}
{"_id": "877", "text": "Jaki dokument sporządza producent skrobi?"}
{"_id": "878", "text": "Co robi minister po uzyskaniu informacji o awarii przemysłowej?"}
{"_id": "879", "text": "Gdzie się ogłasza zamówienia publiczne?"}
{"_id": "880", "text": "Na co zostaje przeznaczona nadwyżka bilansowa?"}
{"_id": "881", "text": "Co może NBP?"}
{"_id": "882", "text": "Co wchodzi w skład dochodów klubu?"}
{"_id": "883", "text": "Czy dłużnik może powołać się na ograniczenie odpowiedzialności?"}
{"_id": "884", "text": "Czy oskarżony może mieć przyznanego obrońcę z urzędu?"}
{"_id": "885", "text": "Jakie prawo przysługuje oskarżonemu?"}
{"_id": "886", "text": "Kto sprawuje nadzór nad uniwersytetem?"}
{"_id": "887", "text": "Gdzie są określone stawki ryczałtu od proboszczów?"}
{"_id": "888", "text": "Kto ustala sieć gimnazjów?"}
{"_id": "889", "text": "Gdzie jest siedziba Chrześcijańskiej Akademii Teologicznej?"}
{"_id": "890", "text": "Jakie obiekty będzie użytkować Wydział Teologii Uniwersytetu?"}
{"_id": "891", "text": "Co się ogłasza w Dzienniku Urzędowym Rzeczypospolitej Polskiej?"}
{"_id": "892", "text": "Kto określa zasady przechowywania umów międzynarodowych?"}
{"_id": "893", "text": "Co stanowi strefę ochronną wokół Pomnika Zagłady?"}
{"_id": "894", "text": "Co jest organem właściwym w sprawach wywłaszczania nieruchomości?"}
{"_id": "895", "text": "Co ma na celu wykorzystywanie danych rachunkowych z gospodarstw rolnych?"}
{"_id": "896", "text": "Czym jest Izba Rzeczników Patentowych?"}
{"_id": "897", "text": "Kiedy powstaje prawo wykonywania zawodu rzecznika patentowego?"}
{"_id": "898", "text": "Jak często Rzecznik patentowy jest zobowiązwany do opłacania składek?"}
{"_id": "899", "text": "Z ilu członków składa się Kolegium wojskowego sądu okręgowego?"}
{"_id": "900", "text": "Kto przeprowadza aplikację dyplomatyczno-konsularną?"}
{"_id": "901", "text": "Co bada Minister Gospodarki w toku postępowania ochronnego"}
{"_id": "902", "text": "Kiedy przywóz towarów na polski obszar celny uważa się za nadmierny?"}
{"_id": "903", "text": "Co robi Minister właściwy do spraw wewnętrznych?"}
{"_id": "904", "text": "Jakie zadania związane są z organizacją COP24?"}
{"_id": "905", "text": "Kiedy upływa kadencja Rady?"}
{"_id": "906", "text": "Co należy zrobić w przypadku wystąpienia różnych marginesów dumpingu?"}
{"_id": "907", "text": "Kogo musi zawiadomić prezes sądu apelacyjnego o toczącej się sprawie sądowej, w której występuje jako strona?"}
{"_id": "908", "text": "Czy posługiwanie się w obrocie prawnym na terytorium Rzeczypospolitej Polskiej wyłącznie obcojęzycznymi nazwami własnymi, jest dozwolone?"}
{"_id": "909", "text": "Czy przy zawieraniu umowy ubezpieczenia morskiego ubezpieczający obowiązany jest podać do wiadomości ubezpieczyciela powszechnie znane okoliczności?"}
{"_id": "910", "text": "Na kogo przechodzą prawa odszkodowania w razie śmierci obwinionego, który w wyniku kasacji postępowania został uniewinniony?"}
{"_id": "911", "text": "Do jakiego stopnia powraca żołnierz w skutku kary pozbawienia stopnia oficerskiego?"}
{"_id": "912", "text": "Na czyj wniosek wydaje się pozwolenie na tranzyt niekrajowego towaru podwójnego zastosowania, którego przemieszczanie ma się zakończyć poza polskim obszarem celnym?"}
{"_id": "913", "text": "Jaki charakter może mieć świadczenie, do spełnienia którego zobowiązuje się emitent obligacji?"}
{"_id": "914", "text": "Kto kieruje działaniami interwencyjnymi w przypadku zdarzenia radiacyjnego powodującego zagrożenie o zasięgu krajowym?"}
{"_id": "915", "text": "Kiedy wchodzi w życie uchwała o przystąpieniu do zrzeszenia?"}
{"_id": "916", "text": "Co jaki czas zostaje złożony raport z realizacji polityki ekologicznej państwa?"}
{"_id": "917", "text": "Czy żłobek może wymagać dodatkowej opłaty za opiekę nad dzieckiem w wymiarze ponad 8 godzin?"}
{"_id": "918", "text": "Czy hipoteka morska na statku w budowie obejmuje materiały przeznaczone do jego budowy?"}
{"_id": "919", "text": "Kto sprawuje nadzór nad sprawami przejazdu przez polskie terytorium należące do urzędów konsularnych?"}
{"_id": "920", "text": "Za czyim pośrednictwem zostaje złożony wniosek o wydanie z terytorium państwa obcego dowodów rzeczowych?"}
{"_id": "921", "text": "Jakie statki mogą żeglować pod polską banderą?"}
{"_id": "922", "text": "W jakim terminie musi zostać przesłane orzeczenie regionalnej komisji dyscyplinarnej?"}
{"_id": "923", "text": "Czy minister właściwy do spraw rolnictwa może wycofać licencję, jeśli armator został skazany wyrokiem za nieumyślne przestępstwo popełnione przy użyciu statku rybackiego?"}
{"_id": "924", "text": "Jakie oddziały tworzy się w miejscowościach niebędących siedzibami sądów apelacyjnych w celu wykonywania zadań instytutu pamięci?"}
{"_id": "925", "text": "Kto sprawuje nadzór nad agencją mienia wojskowego?"}
{"_id": "926", "text": "Jakiej karze podlega wierzyciel, który przyjmuje korzyść za działanie na szkodę innych wierzycieli w związku z postępowaniem upadłościowym?"}
{"_id": "927", "text": "W jakim terminie osoba uprawniona do korzystania z procedury tranzytu powinna przedstawić towary w urzędzie celnym?"}
{"_id": "928", "text": "Jaka musi być powierzchnia apteki ogólnodostępnej?"}
{"_id": "929", "text": "Jaki jest język prac dyplomowych w niepaństwowych szkołach wyższych?"}
{"_id": "930", "text": "Kto może wprowadzić obowiązek kasowania znaków akcyzy?"}
{"_id": "931", "text": "Czy w lasach ochronnych mogą być budowane budowle służące obronności państwa?"}
{"_id": "932", "text": "Za czyim pośrednictwem organy udzielające pomocy przekazują sprawozdania dotyczące udzielonej pomocy?"}
{"_id": "933", "text": "Kto określa procedury pobierania próbek dla wyrobów, które mogą stwarzać zagrożenie dla środowiska?"}
{"_id": "934", "text": "Kto wydaje rozporządzenie o stworzeniu obwodu łowieckiego, w przypadku, gdy ten ma się znajdować na obszarze więcej niż jednego województwa?"}
{"_id": "935", "text": "Kto określa sposoby kontroli urządzeń wodociągowych?"}
{"_id": "936", "text": "Jakie zezwolenie konieczne jest, by było możliwe zatrudnienie cudzoziemca, który nie posiada karty stałego pobytu ani statusu uchodźcy?"}
{"_id": "937", "text": "Co określa regulamin rady nadzorczej?"}
{"_id": "938", "text": "Co określa regulamin rady nadzorczej?"}
{"_id": "939", "text": "Co określa regulamin rady nadzorczej?"}
{"_id": "940", "text": "Co określa regulamin rady nadzorczej?"}
{"_id": "941", "text": "Co określa regulamin rady nadzorczej?"}
{"_id": "942", "text": "Czy Kościół może sprzedawać swoje mienie?"}
{"_id": "943", "text": "Czy Kościół może sprzedawać swoje mienie?"}
{"_id": "944", "text": "Czy Kościół może sprzedawać swoje mienie?"}
{"_id": "945", "text": "Czy Kościół może sprzedawać swoje mienie?"}
{"_id": "946", "text": "Czy Kościół może sprzedawać swoje mienie?"}
{"_id": "947", "text": "Czy Kościół może sprzedawać swoje mienie?"}
{"_id": "948", "text": "Czy Kościół może sprzedawać swoje mienie?"}
{"_id": "949", "text": "Czy kurator zawodowy może podnosić kwalifikacje zawodowe tylko w konkretnej formie kształcenia?"}
{"_id": "950", "text": "Czy kurator zawodowy może podnosić kwalifikacje zawodowe tylko w konkretnej formie kształcenia?"}
{"_id": "951", "text": "Czy kurator zawodowy może podnosić kwalifikacje zawodowe tylko w konkretnej formie kształcenia?"}
{"_id": "952", "text": "Czy kurator zawodowy może podnosić kwalifikacje zawodowe tylko w konkretnej formie kształcenia?"}
{"_id": "953", "text": "Czy kurator zawodowy może podnosić kwalifikacje zawodowe tylko w konkretnej formie kształcenia?"}
{"_id": "954", "text": "Czy kurator zawodowy może podnosić kwalifikacje zawodowe tylko w konkretnej formie kształcenia?"}
{"_id": "955", "text": "Czy kurator zawodowy może podnosić kwalifikacje zawodowe tylko w konkretnej formie kształcenia?"}
{"_id": "956", "text": "Czy można zwalczać zwierzęta stanowiące zagrożenie dla gospodarki człowieka?"}
{"_id": "957", "text": "Czy można zwalczać zwierzęta stanowiące zagrożenie dla gospodarki człowieka?"}
{"_id": "958", "text": "Czy można zwalczać zwierzęta stanowiące zagrożenie dla gospodarki człowieka?"}
{"_id": "959", "text": "Czy można zwalczać zwierzęta stanowiące zagrożenie dla gospodarki człowieka?"}
{"_id": "960", "text": "Czy można zwalczać zwierzęta stanowiące zagrożenie dla gospodarki człowieka?"}
{"_id": "961", "text": "Czy można zwalczać zwierzęta stanowiące zagrożenie dla gospodarki człowieka?"}
{"_id": "962", "text": "Czy oświadczenia oskarżonego, dotyczące zarzucanego mu czynu, złożone biegłemu, mogą stanowić dowód?"}
{"_id": "963", "text": "Czy oświadczenia oskarżonego, dotyczące zarzucanego mu czynu, złożone biegłemu, mogą stanowić dowód?"}
{"_id": "964", "text": "Czy oświadczenia oskarżonego, dotyczące zarzucanego mu czynu, złożone biegłemu, mogą stanowić dowód?"}
{"_id": "965", "text": "Czy oświadczenia oskarżonego, dotyczące zarzucanego mu czynu, złożone biegłemu, mogą stanowić dowód?"}
{"_id": "966", "text": "Czy oświadczenia oskarżonego, dotyczące zarzucanego mu czynu, złożone biegłemu, mogą stanowić dowód?"}
{"_id": "967", "text": "Czy oświadczenia oskarżonego, dotyczące zarzucanego mu czynu, złożone biegłemu, mogą stanowić dowód?"}
{"_id": "968", "text": "Czy rejestr znaków identyfikacyjnych producentów butelek miarowych musi zawierać NIP producenta?"}
{"_id": "969", "text": "Czy rejestr znaków identyfikacyjnych producentów butelek miarowych musi zawierać NIP producenta?"}
{"_id": "970", "text": "Czy rejestr znaków identyfikacyjnych producentów butelek miarowych musi zawierać NIP producenta?"}
{"_id": "971", "text": "Czy skazany, który ukończył 24 lata, może odbywać karę w zakładzie karnym dla młodocianych?"}
{"_id": "972", "text": "Czy skazany, który ukończył 24 lata, może odbywać karę w zakładzie karnym dla młodocianych?"}
{"_id": "973", "text": "Czy skazany, który ukończył 24 lata, może odbywać karę w zakładzie karnym dla młodocianych?"}
{"_id": "974", "text": "Czy skazany, który ukończył 24 lata, może odbywać karę w zakładzie karnym dla młodocianych?"}
{"_id": "975", "text": "Czy skazany, który ukończył 24 lata, może odbywać karę w zakładzie karnym dla młodocianych?"}
{"_id": "976", "text": "Gdzie Kościół może emitować nabożeństwa?"}
{"_id": "977", "text": "Gdzie Kościół może emitować nabożeństwa?"}
{"_id": "978", "text": "Gdzie Kościół może emitować nabożeństwa?"}
{"_id": "979", "text": "Gdzie Kościół może emitować nabożeństwa?"}
{"_id": "980", "text": "Gdzie Kościół może emitować nabożeństwa?"}
{"_id": "981", "text": "Gdzie Kościół może emitować nabożeństwa?"}
{"_id": "982", "text": "Gdzie Kościół może emitować nabożeństwa?"}
{"_id": "983", "text": "Gdzie wysyła się oryginał zaświadczenia lekarskiego?"}
{"_id": "984", "text": "Gdzie wysyła się oryginał zaświadczenia lekarskiego?"}
{"_id": "985", "text": "Gdzie wysyła się oryginał zaświadczenia lekarskiego?"}
{"_id": "986", "text": "Gdzie wysyła się oryginał zaświadczenia lekarskiego?"}
{"_id": "987", "text": "Gdzie wysyła się oryginał zaświadczenia lekarskiego?"}
{"_id": "988", "text": "Ile osób jest wymaganych do utworzenia komitetu inicjatywy ustawodawczej?"}
{"_id": "989", "text": "Ile osób jest wymaganych do utworzenia komitetu inicjatywy ustawodawczej?"}
{"_id": "990", "text": "Ile osób jest wymaganych do utworzenia komitetu inicjatywy ustawodawczej?"}
{"_id": "991", "text": "Ile osób jest wymaganych do utworzenia komitetu inicjatywy ustawodawczej?"}
{"_id": "992", "text": "Ile podpisów wyrażających poparcie należy zebrać w celu rejestracji listy kandydatów na radnych?"}
{"_id": "993", "text": "Ile podpisów wyrażających poparcie należy zebrać w celu rejestracji listy kandydatów na radnych?"}
{"_id": "994", "text": "Ile podpisów wyrażających poparcie należy zebrać w celu rejestracji listy kandydatów na radnych?"}
{"_id": "995", "text": "Ile podpisów wyrażających poparcie należy zebrać w celu rejestracji listy kandydatów na radnych?"}
{"_id": "996", "text": "Ile podpisów wyrażających poparcie należy zebrać w celu rejestracji listy kandydatów na radnych?"}
{"_id": "997", "text": "Ile podpisów wyrażających poparcie należy zebrać w celu rejestracji listy kandydatów na radnych?"}
{"_id": "998", "text": "Jaka jest wysokość świadczenia socjalnego dla pracownika korzystającego z urlopu kolejowego?"}
{"_id": "999", "text": "Jaka jest wysokość świadczenia socjalnego dla pracownika korzystającego z urlopu kolejowego?"}
{"_id": "1000", "text": "Jaka jest wysokość świadczenia socjalnego dla pracownika korzystającego z urlopu kolejowego?"}
{"_id": "1001", "text": "Jaki kodeks reguluje zasady przyznawania odprawy pośmiertnej dla rodziny w przypadku śmierci sędziego?"}
{"_id": "1002", "text": "Jaki kodeks reguluje zasady przyznawania odprawy pośmiertnej dla rodziny w przypadku śmierci sędziego?"}
{"_id": "1003", "text": "Jaki kodeks reguluje zasady przyznawania odprawy pośmiertnej dla rodziny w przypadku śmierci sędziego?"}
{"_id": "1004", "text": "Jaki kodeks reguluje zasady przyznawania odprawy pośmiertnej dla rodziny w przypadku śmierci sędziego?"}
{"_id": "1005", "text": "Jaki kodeks reguluje zasady przyznawania odprawy pośmiertnej dla rodziny w przypadku śmierci sędziego?"}
{"_id": "1006", "text": "Jaki kodeks reguluje zasady przyznawania odprawy pośmiertnej dla rodziny w przypadku śmierci sędziego?"}
{"_id": "1007", "text": "Jaki procent alkoholu musi zawierać wyrób spirytusowy?"}
{"_id": "1008", "text": "Jaki procent alkoholu musi zawierać wyrób spirytusowy?"}
{"_id": "1009", "text": "Jaki procent alkoholu musi zawierać wyrób spirytusowy?"}
{"_id": "1010", "text": "Jaki procent alkoholu musi zawierać wyrób spirytusowy?"}
{"_id": "1011", "text": "Jaki procent alkoholu musi zawierać wyrób spirytusowy?"}
{"_id": "1012", "text": "Jaki procent alkoholu musi zawierać wyrób spirytusowy?"}
{"_id": "1013", "text": "Jakich składników nie mogą zawierać mieszanki paszowe?"}
{"_id": "1014", "text": "Jakich składników nie mogą zawierać mieszanki paszowe?"}
{"_id": "1015", "text": "Jakich składników nie mogą zawierać mieszanki paszowe?"}
{"_id": "1016", "text": "Jakich składników nie mogą zawierać mieszanki paszowe?"}
{"_id": "1017", "text": "Jakich składników nie mogą zawierać mieszanki paszowe?"}
{"_id": "1018", "text": "Jakich składników nie mogą zawierać mieszanki paszowe?"}
{"_id": "1019", "text": "Jakiej karze podlega osoba wybierająca jaja ptaków łownych?"}
{"_id": "1020", "text": "Jakiej karze podlega osoba wybierająca jaja ptaków łownych?"}
{"_id": "1021", "text": "Jakiej karze podlega osoba wybierająca jaja ptaków łownych?"}
{"_id": "1022", "text": "Jakiej karze podlega osoba wybierająca jaja ptaków łownych?"}
{"_id": "1023", "text": "Jakiej karze podlega osoba wybierająca jaja ptaków łownych?"}
{"_id": "1024", "text": "Jakiej karze podlega osoba wybierająca jaja ptaków łownych?"}
{"_id": "1025", "text": "Komu i czemu podlega samorząd rolniczy podczas wykonywania swoich zadań?"}
{"_id": "1026", "text": "Komu i czemu podlega samorząd rolniczy podczas wykonywania swoich zadań?"}
{"_id": "1027", "text": "Komu i czemu podlega samorząd rolniczy podczas wykonywania swoich zadań?"}
{"_id": "1028", "text": "Komu i czemu podlega samorząd rolniczy podczas wykonywania swoich zadań?"}
{"_id": "1029", "text": "Komu i czemu podlega samorząd rolniczy podczas wykonywania swoich zadań?"}
{"_id": "1030", "text": "Komu powierzone jest pełnienie obowiązków Prezesa w przypadku odwołania go w trakcie kadencji?"}
{"_id": "1031", "text": "Komu powierzone jest pełnienie obowiązków Prezesa w przypadku odwołania go w trakcie kadencji?"}
{"_id": "1032", "text": "Komu powierzone jest pełnienie obowiązków Prezesa w przypadku odwołania go w trakcie kadencji?"}
{"_id": "1033", "text": "Komu powierzone jest pełnienie obowiązków Prezesa w przypadku odwołania go w trakcie kadencji?"}
{"_id": "1034", "text": "Komu powierzone jest pełnienie obowiązków Prezesa w przypadku odwołania go w trakcie kadencji?"}
{"_id": "1035", "text": "Kto ogłasza bieżące kursy dolara?"}
{"_id": "1036", "text": "Kto ogłasza bieżące kursy dolara?"}
{"_id": "1037", "text": "Kto ogłasza bieżące kursy dolara?"}
{"_id": "1038", "text": "Kto ogłasza bieżące kursy dolara?"}
{"_id": "1039", "text": "Kto ogłasza bieżące kursy dolara?"}
{"_id": "1040", "text": "Kto wyznacza termin usunięcia braków wynikłych z niedopełnienia przepisów prawa przez spółkę?"}
{"_id": "1041", "text": "Kto wyznacza termin usunięcia braków wynikłych z niedopełnienia przepisów prawa przez spółkę?"}
{"_id": "1042", "text": "Kto wyznacza termin usunięcia braków wynikłych z niedopełnienia przepisów prawa przez spółkę?"}
{"_id": "1043", "text": "Kto wyznacza termin usunięcia braków wynikłych z niedopełnienia przepisów prawa przez spółkę?"}
{"_id": "1044", "text": "Kto wyznacza termin usunięcia braków wynikłych z niedopełnienia przepisów prawa przez spółkę?"}
{"_id": "1045", "text": "Kto wyznacza termin usunięcia braków wynikłych z niedopełnienia przepisów prawa przez spółkę?"}
{"_id": "1046", "text": "Który spośród kilku ratujących ma prawo do wynagrodzenia?"}
{"_id": "1047", "text": "Który spośród kilku ratujących ma prawo do wynagrodzenia?"}
{"_id": "1048", "text": "Który spośród kilku ratujących ma prawo do wynagrodzenia?"}
{"_id": "1049", "text": "Który spośród kilku ratujących ma prawo do wynagrodzenia?"}
{"_id": "1050", "text": "Którzy pracownicy Najwyższej Izby Kontroli nie mogą zrzeszać się w związkach zawodowych?"}
{"_id": "1051", "text": "Którzy pracownicy Najwyższej Izby Kontroli nie mogą zrzeszać się w związkach zawodowych?"}
{"_id": "1052", "text": "Którzy pracownicy Najwyższej Izby Kontroli nie mogą zrzeszać się w związkach zawodowych?"}
{"_id": "1053", "text": "Którzy pracownicy Najwyższej Izby Kontroli nie mogą zrzeszać się w związkach zawodowych?"}
{"_id": "1054", "text": "Na czyj wniosek wszczyna się postępowanie dyscyplinarne?"}
{"_id": "1055", "text": "Na czyj wniosek wszczyna się postępowanie dyscyplinarne?"}
{"_id": "1056", "text": "Na czyj wniosek wszczyna się postępowanie dyscyplinarne?"}
{"_id": "1057", "text": "Na czyj wniosek wszczyna się postępowanie dyscyplinarne?"}
{"_id": "1058", "text": "Na czyj wniosek wszczyna się postępowanie dyscyplinarne?"}
{"_id": "1059", "text": "Na czyj wniosek wszczyna się postępowanie dyscyplinarne?"}
{"_id": "1060", "text": "Na czyj wniosek wszczyna się postępowanie dyscyplinarne?"}
{"_id": "1061", "text": "Na podstawie czego określa się poziom uczestnictwa akcjonariusza w życiu spółki?"}
{"_id": "1062", "text": "Na podstawie czego określa się poziom uczestnictwa akcjonariusza w życiu spółki?"}
{"_id": "1063", "text": "Na podstawie czego określa się poziom uczestnictwa akcjonariusza w życiu spółki?"}
{"_id": "1064", "text": "Na podstawie czego określa się poziom uczestnictwa akcjonariusza w życiu spółki?"}
{"_id": "1065", "text": "Na podstawie czego określa się poziom uczestnictwa akcjonariusza w życiu spółki?"}
{"_id": "1066", "text": "Na podstawie czego określa się poziom uczestnictwa akcjonariusza w życiu spółki?"}
{"_id": "1067", "text": "Na podstawie czego określa się poziom uczestnictwa akcjonariusza w życiu spółki?"}
{"_id": "1068", "text": "Od czego może zostać uzależnione udzielenie pomocy w celu utrzymania poziomu zatrudnienia?"}
{"_id": "1069", "text": "Od czego może zostać uzależnione udzielenie pomocy w celu utrzymania poziomu zatrudnienia?"}
{"_id": "1070", "text": "Od czego może zostać uzależnione udzielenie pomocy w celu utrzymania poziomu zatrudnienia?"}
{"_id": "1071", "text": "Od czego może zostać uzależnione udzielenie pomocy w celu utrzymania poziomu zatrudnienia?"}
{"_id": "1072", "text": "Od czego może zostać uzależnione udzielenie pomocy w celu utrzymania poziomu zatrudnienia?"}
{"_id": "1073", "text": "Od czego może zostać uzależnione udzielenie pomocy w celu utrzymania poziomu zatrudnienia?"}
{"_id": "1074", "text": "Od kiedy obowiązują rozporządzenia opiniowane przez Prezesa Urzędu Ochrony Konkurencji i Konsumentów?"}
{"_id": "1075", "text": "Od kiedy obowiązują rozporządzenia opiniowane przez Prezesa Urzędu Ochrony Konkurencji i Konsumentów?"}
{"_id": "1076", "text": "Od kiedy obowiązują rozporządzenia opiniowane przez Prezesa Urzędu Ochrony Konkurencji i Konsumentów?"}
{"_id": "1077", "text": "Od kiedy obowiązują rozporządzenia opiniowane przez Prezesa Urzędu Ochrony Konkurencji i Konsumentów?"}
{"_id": "1078", "text": "Od kiedy obowiązują rozporządzenia opiniowane przez Prezesa Urzędu Ochrony Konkurencji i Konsumentów?"}
{"_id": "1079", "text": "Od kiedy obowiązują rozporządzenia opiniowane przez Prezesa Urzędu Ochrony Konkurencji i Konsumentów?"}
{"_id": "1080", "text": "W jakich przypadkach diagnosta laboratoryjny jest zwolniony z zachowania tajemnicy zawodowej?"}
{"_id": "1081", "text": "W jakich przypadkach diagnosta laboratoryjny jest zwolniony z zachowania tajemnicy zawodowej?"}
{"_id": "1082", "text": "W jakich przypadkach diagnosta laboratoryjny jest zwolniony z zachowania tajemnicy zawodowej?"}
{"_id": "1083", "text": "W jakich przypadkach diagnosta laboratoryjny jest zwolniony z zachowania tajemnicy zawodowej?"}
{"_id": "1084", "text": "W jakich przypadkach diagnosta laboratoryjny jest zwolniony z zachowania tajemnicy zawodowej?"}
{"_id": "1085", "text": "W jakich sytuacjach dozwolone jest legitymowanie się paszportem dyplomatycznym?"}
{"_id": "1086", "text": "W jakich sytuacjach dozwolone jest legitymowanie się paszportem dyplomatycznym?"}
{"_id": "1087", "text": "W jakich sytuacjach dozwolone jest legitymowanie się paszportem dyplomatycznym?"}
{"_id": "1088", "text": "W jakich sytuacjach dozwolone jest legitymowanie się paszportem dyplomatycznym?"}
{"_id": "1089", "text": "W jakich sytuacjach dozwolone jest legitymowanie się paszportem dyplomatycznym?"}
{"_id": "1090", "text": "W jakich sytuacjach dozwolone jest legitymowanie się paszportem dyplomatycznym?"}
{"_id": "1091", "text": "W skład jakiego ministerstwa wchodzi Sztab Generalny Wojska Polskiego?"}
{"_id": "1092", "text": "W skład jakiego ministerstwa wchodzi Sztab Generalny Wojska Polskiego?"}
{"_id": "1093", "text": "W skład jakiego ministerstwa wchodzi Sztab Generalny Wojska Polskiego?"}
{"_id": "1094", "text": "W skład jakiego ministerstwa wchodzi Sztab Generalny Wojska Polskiego?"}
{"_id": "1095", "text": "W skład jakiego ministerstwa wchodzi Sztab Generalny Wojska Polskiego?"}
{"_id": "1096", "text": "W skład jakiego ministerstwa wchodzi Sztab Generalny Wojska Polskiego?"}
{"_id": "1097", "text": "Z kim należy uzgadniać wysokość corocznych odpisów na fundusze specjalne NBP?"}
{"_id": "1098", "text": "Z kim należy uzgadniać wysokość corocznych odpisów na fundusze specjalne NBP?"}
{"_id": "1099", "text": "Z kim należy uzgadniać wysokość corocznych odpisów na fundusze specjalne NBP?"}
{"_id": "1100", "text": "Z kim należy uzgadniać wysokość corocznych odpisów na fundusze specjalne NBP?"}
{"_id": "1101", "text": "Z kim należy uzgadniać wysokość corocznych odpisów na fundusze specjalne NBP?"}
{"_id": "1102", "text": "Z kim należy uzgadniać wysokość corocznych odpisów na fundusze specjalne NBP?"}
{"_id": "1103", "text": "Na dołączenie czego do protokołu może zezwolić organ podatkowy?"}
{"_id": "1104", "text": "Do czego jest proporcjonalna wielkość limitu przyznawanego producentowi suszu?"}
{"_id": "1105", "text": "Kiedy została sporządzona Międzynarodowa Konwencja Przeciwko Braniu Zakładników?"}
{"_id": "1106", "text": "Kto dokonuje przekształcenia funduszu?"}
{"_id": "1107", "text": "Czy prezes Rady Ministrów określa wysokość wynagrodzenia wiceprzewodniczącego Rady Służby Cywilnej?"}
{"_id": "1108", "text": "Czy spółka partnerska jest spółką handlową?"}
{"_id": "1109", "text": "Za co odpowiada osoba przystępująca do spółki w charakterze komandytariusza?"}
{"_id": "1110", "text": "Czy dotychczasowe przepisy wykonawcze zachowują moc po wydaniu nowych przepisów wykonawczych?"}
{"_id": "1111", "text": "O czym jest tekst ustawy z dnia 10 kwietnia 1974 r.?"}
{"_id": "1112", "text": "Jakiej szerokości jest pas gruntu stanowiący strefę ochronną?"}
{"_id": "1113", "text": "Czy prowadzący skład celny jest odpowiedzialny za zapewnienie, aby towary złożone w składzie celnym nie zostały usunięte?"}
{"_id": "1114", "text": "Jakie dokumenty obowiązany jest przechowywać przedsiębiorca?"}
{"_id": "1115", "text": "Jak długo trwa kadencja organów okręgowych izb?"}
{"_id": "1116", "text": "W jakim miesiącu odbył się powszechny spis rolny w 1996 roku?"}
{"_id": "1117", "text": "Czy skazani nie mogą kierować skarg do organów powołanych na podstawie ratyfikowanych przez Rzeczpospolitą Polską umów międzynarodowych dotyczących ochrony praw człowieka?"}
{"_id": "1118", "text": "Do czego obowiązany jest przewoźnik po przyjęciu ładunku na statek?"}
{"_id": "1119", "text": "Jaką ustawą uregulowany jest spis ludności?"}
{"_id": "1120", "text": "Co muszą zawierać hasła referendalne ogłaszane w prasie drukowanej lub w telewizji?"}
{"_id": "1121", "text": "W czyjej dyspozycji pozostaje fundusz nagród w służbie cywilnej?"}
{"_id": "1122", "text": "Czy dyrektor regionalnej dyrekcji Lasów Państwowych jest organem właściwym w sprawach ochrony gruntów rolnych w obszarze parków narodowych?"}
{"_id": "1123", "text": "W jakiej ustawie określona jest ochrona informacji kryminalnych?"}
{"_id": "1124", "text": "Na jakie cele może wydawać środki komitet wyborczy?"}
{"_id": "1125", "text": "Co robi ambasador przy organizacji międzynarodowej?"}
{"_id": "1126", "text": "Kto opłaca obowiązkowe składki na fundusz pracy?"}
{"_id": "1127", "text": "Jakiemu obniżeniu ulega kwartalna stawka ryczałtu?"}
{"_id": "1128", "text": "Po upływie jakiego czasu następuje usunięcie z urzędu wzmianki o orzeczeniu dyscyplinarnym z Rejestru Ukaranych?"}
{"_id": "1129", "text": "Jakie zezwolenia wydaje się na obrót towarem podwójnego zastosowania?"}
{"_id": "1130", "text": "Jaki związek tworzą banki spółdzielcze?"}
{"_id": "1131", "text": "Kto wydaje decyzję o uznaniu praktyki za ograniczającą konkurencję?"}
{"_id": "1132", "text": "Kto powołuje okręgowych inspektorów rybołówstwa morskiego?"}
{"_id": "1133", "text": "W jakim momencie powstaje obowiązek podatkowy?"}
{"_id": "1134", "text": "W jakim momencie powstaje spółka komandytowo-akcyjna?"}
{"_id": "1135", "text": "Ile przynajmniej godzin odpoczynku przysługuje kierowcy w ciągu każdej doby?"}
{"_id": "1136", "text": "Czy skazanie prawomocnym wyrokiem sądowym może skutkować zwolnieniem żołnierza z wojska?"}
{"_id": "1137", "text": "Kogo zwalnia ze służby szef BOR?"}
{"_id": "1138", "text": "Czy skarga bez wskazania określonego naruszenia prawa bądź interesu prawnego jest zasadna?"}
{"_id": "1139", "text": "Podczas jakich wydarzeń przełożony jest zobowiązany powiadomić podporządkowanych mu żołnierzy o udzieleniu wyróżnienia?"}
{"_id": "1140", "text": "Kto sporządza projekt krajowej strategii ochrony i zrównoważonego użytkowania różnorodności biologicznej?"}
{"_id": "1141", "text": "Czym są negocjacje bez ogłoszenia?"}
{"_id": "1142", "text": "Czy prawo do wykonywania zawodu lekarza było kiedyś równoważne prawu do wykonywania zawodu stomatologa?"}
{"_id": "1143", "text": "Rozdział V jakiej konwencji był uwzględniony we szczegółowych warunkach bezpiecznego uprawniania żeglugi?"}
{"_id": "1144", "text": "Czy nieopłacanie w terminie składek na ubezpieczenie zdrowotne kasa powszechnego ubezpieczenia zdrowotnego jest bezkarne?"}
{"_id": "1145", "text": "Czy środki ochrony roślin mogą być nakładane poprzez niesprawny technicznie sprzęt?"}
{"_id": "1146", "text": "Kiedy wynalazek uznajemy za nadający się do wykorzystania w przemyśle?"}
{"_id": "1147", "text": "Czy Ochotnicze Hufce Pracy zajmują się młodzieżą zaniedbaną wychowawczo?"}
{"_id": "1148", "text": "Jak nazywa się najwyższa samorządowa organizacja ruchu spółdzielczego?"}
{"_id": "1149", "text": "Na czyj wniosek osoba małoletnia może być zwolniona przez policję?"}
{"_id": "1150", "text": "Gdzie mieści się siedziba Agencji Budowy i Eksploatacji Autostrad?"}
{"_id": "1151", "text": "Czy osoba, która deklaruje narodowość polską i posiadała w przeszłości obywatelstwo polskie jest uznawana za osobę polskiego pochodzenia?"}
{"_id": "1152", "text": "Gdzie mogą być przekazywana zatrzymane żywe zwierzęta?"}
{"_id": "1153", "text": "Czy żołnierzom zawodowym - kobietom przysługuje urlop macierzyński?"}
{"_id": "1154", "text": "Czy osoba, która pobrała nienależnie świadczenie rodzinne powinna je zwrócić?"}
{"_id": "1155", "text": "Jakiej ochronie podlegają obiekty jądrowe?"}
{"_id": "1156", "text": "Czy nakłady poniesione przez gminę w okresie władania nieruchomością podlegają zwrotowi?"}
{"_id": "1157", "text": "Kto wybiera likwidatora spółdzielni?"}
{"_id": "1158", "text": "Czy za użytkowanie wieczyste gruntów przez zakłady charytatywno-opiekuńcze pobiera się opłaty?"}
{"_id": "1159", "text": "Jaki organ wydaje decyzję o uznaniu praktyki za ograniczającą konkurencję?"}
{"_id": "1160", "text": "Komu podlegają okręgowi inspektorzy rybołówstwa morskiego?"}
{"_id": "1161", "text": "W jakim momencie na giełdzie powstaje obowiązek podatkowy?"}
{"_id": "1162", "text": "Do czego jest obowiązany inspektor w przypadku, gdy w wyniku użycia broni palnej doszło do wyrządzenia szkody w mieniu?"}
{"_id": "1163", "text": "Jeśli ustawa nie stanowi inaczej, w jakim postępowaniu dokonuje czynności prokurator?"}
{"_id": "1164", "text": "Jakie pozwolenia sąd może wydać przedstawicielom radia, telewizji, filmu i prasy?"}
{"_id": "1165", "text": "Które dane powinno zawierać zaświadczenie kierowcy, które on musi przedstawić do przeprowadzenia kontroli?"}
{"_id": "1166", "text": "Przez kogo jest prowadzony kataster wodny dla obszaru państwa?"}
{"_id": "1167", "text": "Kto mianuje lub odwołuje Ambasadora?"}
{"_id": "1168", "text": "W jakich przypadkach można zwolnić funkcjonariusza celnego ze służby?"}
{"_id": "1169", "text": "Co przysługuje funkcjonariuszowi celnemu, który na podstawie innych przepisów wykonuje stałe zadania służbowe poza polskim obszarem celnym?"}
{"_id": "1170", "text": "Co jest przedmiotem działalności funduszu inwestycyjnego?"}
{"_id": "1171", "text": "Kto jest obowiązany do udzielania pomocy Instytutowi Pamięci w realizacji zadań Instytutu?"}
{"_id": "1172", "text": "Jak długi może być okres zawieszenia wykonywania obowiązków powiatowego lekarza weterynarii przez Głównego Lekarza Wterynarii?"}
{"_id": "1173", "text": "Kogo zarządcy obwodów łowieckich są obowiązani zawiadomić o dostrzeżonych objawach chorób zwierząt dziko żyjących, które mogą być przeniesione na ludzi?"}
{"_id": "1174", "text": "Co jest podstawowym trybem udzielania zamówienia publicznego?"}
{"_id": "1175", "text": "Jakiej karze podlegają ci, którzy, nie będąc do tego uprawnionymi, z chęci osiągnięcia korzyści majątkowej trudnią się sprzedażą losów?"}
{"_id": "1176", "text": "Na jakich zasadach wykonuje działalność przedsiębiorca?"}
{"_id": "1177", "text": "Jaki musi być dochód osoby bezrobotnej żeby zachowywać status bezrobotnego w przypadku gdy podjęła zatrudnienie?"}
{"_id": "1178", "text": "W którym dniu kolejowe stacje sanitarno-epidemiologiczne zostają przyjęte przez powiatowe stacje sanitarno-epidemiologiczne?"}
{"_id": "1179", "text": "Jakij karze podlegają osoby, które utrudniają przeprowadzenie przez uprawnione organy kontroli działalności gospodarczej w zakresie wytwarzania lub obrotu bronią?"}
{"_id": "1180", "text": "Kto sprawuje nadzór nad działalnością samorządu w zakresie spraw finansowych?"}
{"_id": "1181", "text": "Kto może przeprowadzać badania kliniczne wyrobów medycznych?"}
{"_id": "1182", "text": "Przepisów których artkułów nie stosuje się do zbrodni przeciwko pokojowi, ludzkości i przestępstw wojennych?"}
{"_id": "1183", "text": "Kto określa zasady odpowiedzialności dyscyplinarnej za naruszenie przepisów antydopingowych?"}
{"_id": "1184", "text": "W jakim terminie konsument może odstąpić od umowy o kredyt konsumencki bez nadania przyczyny?"}
{"_id": "1185", "text": "Do czego jest uprawniony komandytariusz?"}
{"_id": "1186", "text": "Gdzie Bank Gospodarstwa Krajowego przekazuje środki uzyskane od banku, który udzielił kredyt, który został w części lub w całości wykorzystany niezgodnie z przeznaczeniem?"}
{"_id": "1187", "text": "W którym okresie czasu wierni Kościoła mają prawo do zwolnienia od pracy i nauki na czas święta adwentystycznego?"}
{"_id": "1188", "text": "Ile może wynosić kapitał zakładowy spółek akczyjnych-organizacji do 1 stycznia 2003 r.?"}
{"_id": "1189", "text": " Kto sprauje nadzór nad przestrzeganiem  przepisów ustawy, zapewniając ochronę interesów odbiorców usług  certyfikacyjnych?"}
{"_id": "1190", "text": " Czy komercjalizacja PKP, w rozumieniu ustawy, polega na przekształceniu PKP w spółkę akcyjną?"}
{"_id": "1191", "text": " Czy uchwały zgromadzenia podejmowane są bezwzględną większością głosów statutowej liczby członków zgromadzenia?"}
{"_id": "1192", "text": " Co stanowi przyczynę usprawiedliwiającą nieobecność pracownika w pracy?"}
{"_id": "1193", "text": " Z ilu osób składa się Zarząd spółki celowej?"}
{"_id": "1194", "text": " W czyjej obecności dokonuje się czynności kontrolnych?"}
{"_id": "1195", "text": "  zamawiający może udzielić zamówienia w trybie zapytania o cenę?"}
{"_id": "1196", "text": " Czy kościelna osoba prawna odpowiada za zobowiązania innej kościelnej osoby prawnej?"}
{"_id": "1197", "text": " Co jest warunkiem dopuszczenia do obrotu towarów, o których mowa w art. 1 ust. 2 w wypadku ustanowienia środka ochronnego?"}
{"_id": "1198", "text": " Czy posiadacz gruntów może, bez zgody uprawnionego hodowcy, stosować materiał ze zbioru jako materiał siewny odmiany chronionej?"}
{"_id": "1199", "text": " Jak można podwyższyć kapitał zakładowy?"}
{"_id": "1200", "text": " Kto dokonuje zgłoszenia zamiaru koncentracji?"}
{"_id": "1201", "text": " Co obejmuje stosowanie promieniowania jonizującego w celach medycznych?"}
{"_id": "1202", "text": " Przy czyjej pomocy szef Służby Cywilnej wykonuje zadania wynikające z ustawy?"}
{"_id": "1203", "text": " Czy prawo z rejestracji rozciąga się na działania dotyczące kopii chronionej topografii?"}
{"_id": "1204", "text": " Do czego są zobowiązani prowadzący badania statystyczne statystyki publicznej?"}
{"_id": "1205", "text": " Co należy przestrzegać w procesie produkcji przetworów grzybowych, środków spożywczych zawierających grzyby, skupie, przechowywaniu lub sprzedaży grzybów?"}
{"_id": "1206", "text": " Czy powiat samodzielnie prowadzi gospodarkę finansową na podstawie budżetu  powiatu?"}
{"_id": "1207", "text": " Co jest jednostkami organizacyjnymi samorządów zawodowych?"}
{"_id": "1208", "text": " Kto ma prawo żądać wydania spółce korzyści, jakie osiągnął?"}
{"_id": "1209", "text": " Gdzie są przekazywane dochody jeżeli osoba prawna lub jednostka organizacyjna nie mająca osobowości prawnej posiada wyodrębnione organizacyjnie zakłady (oddziały) położone na  terenie gminy innej, niż gmina właściwa dla siedziby podatnika?"}
{"_id": "1210", "text": " Na jaki okres Kierownik urzędu powołuje rzecznika dyscyplinarnego urzędu?"}
{"_id": "1211", "text": " Kto prowadzi rejestr zawierający informacje o terenach, na których stwierdzono przekroczenie dopuszczalnych poziomów pólelektromagnetycznych w środowisku?"}
{"_id": "1212", "text": " Nad jakimi organami sprawuje nadzór wojewoda?"}
{"_id": "1213", "text": " Czy kościelne osoby prawne mają prawo do zbierania ofiar na cele religijne?"}
{"_id": "1214", "text": " Jakiej karze podlega ten kto dostarcza mleko podmiotowi skupującemu niewpisanemu do rejestru podmiotów?"}
{"_id": "1215", "text": " Komu przysługuje prawo do wpłat na IKE?"}
{"_id": "1216", "text": "Jakimi funduszami są gminne i powiatowe fundusze w rozumieniu ustawy o finansach publicznych?"}
{"_id": "1217", "text": "Która jednostka organizacyjna wyznacza osobę odpowiedzialną za nadzorowanie i kontrolę w zakresie wykonywania przez przedsiębiorcę obowiązku ochrony przekazanych im informacji niejawnych?"}
{"_id": "1218", "text": "Kto powołuje komisję dyscyplinarną urzędu spośród członków korpusu służby cywilnej?"}
{"_id": "1219", "text": "W jakim terminie należy dostosować umowy o przyłączenie źródeł do sieci?"}
{"_id": "1220", "text": "Kto określi warunki i tryb usprawiedliwienia niestawiennictwa oskarżonych, świadków i innych uczestników procesu z powodu choroby?"}
{"_id": "1221", "text": "Czego nie wolno wnosić do budynków sądowych?"}
{"_id": "1222", "text": "W skutek czego następuje wygaśnięcie członkostwa w obwodowej komisji wyborczej?"}
{"_id": "1223", "text": "Pod jakim warunkiem należy podać informację o wszczęciu postępowania do publicznej wiadomości?"}
{"_id": "1224", "text": "Jakich informacji może zażądać dyrektor urzędu morskiego od statku przepływającego przez polskie obszary morskie?"}
{"_id": "1225", "text": "Jakiej kontroli podlegają towary przywożone z zagranicy?"}
{"_id": "1226", "text": "Do kogo sąd przesyła odpis wyroku w razie orzeczenia podania wyroku do publicznej wiadomości przez ogłoszenie w czasopiśmie?"}
{"_id": "1227", "text": "Kto składa wniosek o wpis produktów do rejestrów produktów?"}
{"_id": "1228", "text": "Jakie dane obejmuje rejestr detektywów?"}
{"_id": "1229", "text": "Pod jakim warunkiem współwłaściciele mogą dokonać podziału nieruchomości?"}
{"_id": "1230", "text": "Czy zmiana wysokości emerytur w ramach waloryzacji następuje z urzędu?"}
{"_id": "1231", "text": "Kto określi wykaz organizmów szkodliwych podlegających obowiązkowi zwalczania?"}
{"_id": "1232", "text": "Kto jest właściwy do rozstrzygania wniosków państwa obcego, dotyczących wydania przedmiotów stanowiących dowody rzeczowe?"}
{"_id": "1233", "text": "W jaki sposób Prezes Narodowego Banku Polskiego określi obowiązkowy zakres informacji dotyczących stanu oszczędności zgromadzonych na rachunkach oszczędnościowo-kredytowych?"}
{"_id": "1234", "text": "Jaki jest limit na ubytki dochodów budżetu państwa z tytułu cła?"}
{"_id": "1235", "text": "W skutek czego następuje wygaśnięcie mandatu radnego?"}
{"_id": "1236", "text": "Do kogo stosuje się przepis dotyczący przekazania Prezesowi Urzędu Transportu Kolejowego?"}
{"_id": "1237", "text": "Co zawiera zgłoszenie ciężkiego działania niepożądanego do ośrodka administrującego?"}
{"_id": "1238", "text": "Do czego są obowiązane właściwe organy Państwowej Straży Pożarnej w razie wystąpienia awarii przemysłowej?"}
{"_id": "1239", "text": "Co może być dokumentem określającym niezbędny dla bezpieczeństwa morskiego skład załogi?"}
{"_id": "1240", "text": "Co należy do wyłącznej właściwości rady powiatu?"}
{"_id": "1241", "text": "Jakie przepisy stosuje się do gospodarki finansowej związku powiatów?"}
{"_id": "1242", "text": "Co jest składane w pierwszym etapie przetargu dwustopniowego?"}
{"_id": "1243", "text": "Która jednostka organizacyjna wyznacza osobę odpowiedzialną za nadzorowanie i kontrolę w zakresie wykonywania przez przedsiębiorcę obowiązku ochrony przekazanych im informacji niejawnych?"}
{"_id": "1244", "text": "Która jednostka organizacyjna wyznacza osobę odpowiedzialną za nadzorowanie i kontrolę w zakresie wykonywania przez przedsiębiorcę obowiązku ochrony przekazanych im informacji niejawnych?"}
{"_id": "1245", "text": "Kto powołuje komisję dyscyplinarną urzędu spośród członków korpusu służby cywilnej?"}
{"_id": "1246", "text": "Kto powołuje komisję dyscyplinarną urzędu spośród członków korpusu służby cywilnej?"}
{"_id": "1247", "text": "Kto powołuje komisję dyscyplinarną urzędu spośród członków korpusu służby cywilnej?"}
{"_id": "1248", "text": "Kto określi warunki i tryb usprawiedliwienia niestawiennictwa oskarżonych, świadków i innych uczestników procesu z powodu choroby?"}
{"_id": "1249", "text": "Pod jakim warunkiem należy podać informację o wszczęciu postępowania do publicznej wiadomości?"}
{"_id": "1250", "text": "Jakiej kontroli podlegają towary przywożone z zagranicy?"}
{"_id": "1251", "text": "Jakiej kontroli podlegają towary przywożone z zagranicy?"}
{"_id": "1252", "text": "Do kogo sąd przesyła odpis wyroku w razie orzeczenia podania wyroku do publicznej wiadomości przez ogłoszenie w czasopiśmie?"}
{"_id": "1253", "text": "Czy zmiana wysokości emerytur w ramach waloryzacji następuje z urzędu?"}
{"_id": "1254", "text": "Czy zmiana wysokości emerytur w ramach waloryzacji następuje z urzędu?"}
{"_id": "1255", "text": "Kto określi wykaz organizmów szkodliwych podlegających obowiązkowi zwalczania?"}
{"_id": "1256", "text": "Jaki jest limit na ubytki dochodów budżetu państwa z tytułu cła?"}
{"_id": "1257", "text": "Jaki jest limit na ubytki dochodów budżetu państwa z tytułu cła?"}
{"_id": "1258", "text": "Do kogo stosuje się przepis dotyczący przekazania Prezesowi Urzędu Transportu Kolejowego?"}
{"_id": "1259", "text": "Do kogo stosuje się przepis dotyczący przekazania Prezesowi Urzędu Transportu Kolejowego?"}
{"_id": "1260", "text": "Do czego są obowiązane właściwe organy Państwowej Straży Pożarnej w razie wystąpienia awarii przemysłowej?"}
{"_id": "1261", "text": "Do czego są obowiązane właściwe organy Państwowej Straży Pożarnej w razie wystąpienia awarii przemysłowej?"}
{"_id": "1262", "text": "Do czego są obowiązane właściwe organy Państwowej Straży Pożarnej w razie wystąpienia awarii przemysłowej?"}
{"_id": "1263", "text": "Co może być dokumentem określającym niezbędny dla bezpieczeństwa morskiego skład załogi?"}
{"_id": "1264", "text": "Jakie przepisy stosuje się do gospodarki finansowej związku powiatów?"}
{"_id": "1265", "text": "Kiedy zostaną powołani sędziowie łowieccy oraz rzecznicy dyscyplinarni i ich zastępcy pierwszej kadencji?"}
{"_id": "1266", "text": "Kto określi wysokość składki na ubezpiecznie społeczne?"}
{"_id": "1267", "text": "Kto określi wysokość składki na ubezpiecznie społeczne?"}
{"_id": "1268", "text": "Od czego rozpoczyna się przewód sądowy?"}
{"_id": "1269", "text": "Od czego rozpoczyna się przewód sądowy?"}
{"_id": "1270", "text": "Od czego rozpoczyna się przewód sądowy?"}
{"_id": "1271", "text": "Jakiej karze podlega osoba wprowadzająca do obrotu produkt kosmetyczny bez spełnienia wymogów dotyczących dokumentacji produktu?"}
{"_id": "1272", "text": "Jakiej karze podlega osoba wprowadzająca do obrotu produkt kosmetyczny bez spełnienia wymogów dotyczących dokumentacji produktu?"}
{"_id": "1273", "text": "Jakiej karze podlega osoba wprowadzająca do obrotu produkt kosmetyczny bez spełnienia wymogów dotyczących dokumentacji produktu?"}
{"_id": "1274", "text": "Jakiej karze podlega osoba wprowadzająca do obrotu produkt kosmetyczny bez spełnienia wymogów dotyczących dokumentacji produktu?"}
{"_id": "1275", "text": "Jakiej karze podlega osoba wprowadzająca do obrotu produkt kosmetyczny bez spełnienia wymogów dotyczących dokumentacji produktu?"}
{"_id": "1276", "text": "Czy wydatki budżetowe ujęte w budżecie państwa w części obrona narodowa mogą być wykorzystane na inne cele?"}
{"_id": "1277", "text": "Czy wydatki budżetowe ujęte w budżecie państwa w części obrona narodowa mogą być wykorzystane na inne cele?"}
{"_id": "1278", "text": "Czy zamknięcie składowiska odpadów lub jego wydzielonej części wymaga zgody właściwego organu?"}
{"_id": "1279", "text": "Kto korzysta z ochrony przewidzianej w Kodeksie karnym dla funkcjonariuszy publicznych?"}
{"_id": "1280", "text": "Kto korzysta z ochrony przewidzianej w Kodeksie karnym dla funkcjonariuszy publicznych?"}
{"_id": "1281", "text": "Kto korzysta z ochrony przewidzianej w Kodeksie karnym dla funkcjonariuszy publicznych?"}
{"_id": "1282", "text": "Kto korzysta z ochrony przewidzianej w Kodeksie karnym dla funkcjonariuszy publicznych?"}
{"_id": "1283", "text": "Kto korzysta z ochrony przewidzianej w Kodeksie karnym dla funkcjonariuszy publicznych?"}
{"_id": "1284", "text": "Gdzie powinna być prowadzona działalność gospodarcza w zakresie wytwarzania środków żywienia zwierząt?"}
{"_id": "1285", "text": "Z kim współdziała dyrektor zakładu karnego dla realizacji celów kary?"}
{"_id": "1286", "text": "Zgodnie z czym izby prowadzą rachunkowość i sprawozdawczość?"}
{"_id": "1287", "text": "Zgodnie z czym izby prowadzą rachunkowość i sprawozdawczość?"}
{"_id": "1288", "text": "Kto odpowiada za ochronę informacji niejawnych?"}
{"_id": "1289", "text": "Do czego emitowania w publicznych środkach masowego przekazu ma prawo Kościół?"}
{"_id": "1290", "text": "Do czego emitowania w publicznych środkach masowego przekazu ma prawo Kościół?"}
{"_id": "1291", "text": "Do czego emitowania w publicznych środkach masowego przekazu ma prawo Kościół?"}
{"_id": "1292", "text": "Do czego emitowania w publicznych środkach masowego przekazu ma prawo Kościół?"}
{"_id": "1293", "text": "Do czego emitowania w publicznych środkach masowego przekazu ma prawo Kościół?"}
{"_id": "1294", "text": "Ile powinien wynosić co najmniej kapitał zakładowy spółki?"}
{"_id": "1295", "text": "Ile powinien wynosić co najmniej kapitał zakładowy spółki?"}
{"_id": "1296", "text": "Z jakim dniem tworzy się urzędy marszałkowskie w miastach będących siedzibami władz samorządu województwa?"}
{"_id": "1297", "text": "Od czego uzależnione jest korzystanie z gospodarczej procedury celnej?"}
{"_id": "1298", "text": "Od czego uzależnione jest korzystanie z gospodarczej procedury celnej?"}
{"_id": "1299", "text": "Jakiemu żołnierzowi przysługuje renta inwalidzka?"}
{"_id": "1300", "text": "Co mogą powołać podmioty gospodarcze prowadzące działalność na terenie strefy?"}
{"_id": "1301", "text": "Z czego wyłącznie mogą być produkowane wina gronowe?"}
{"_id": "1302", "text": "Z czego wyłącznie mogą być produkowane wina gronowe?"}
{"_id": "1303", "text": "Co tworzy Skarb Państwa w celu przygotowania i wykonania przedsięwzięć Euro 2012?"}
{"_id": "1304", "text": "Co tworzy Skarb Państwa w celu przygotowania i wykonania przedsięwzięć Euro 2012?"}
{"_id": "1305", "text": "Co należy do obowiązków osoby wykwalifikowanej odpowiedzialnej za prowadzenie hurtowni farmaceutycznej?"}
{"_id": "1306", "text": "W jaki sposób odpowiada sędzia za wykroczenia?"}
{"_id": "1307", "text": "W jaki sposób odpowiada sędzia za wykroczenia?"}
{"_id": "1308", "text": "W jaki sposób odpowiada sędzia za wykroczenia?"}
{"_id": "1309", "text": "Czyim zadaniem jest ochrona przed powodzią oraz suszą?"}
{"_id": "1310", "text": "W jakim wymiarze żołnierze zawodowi otrzymują corocznie urlop wypoczynkowy?"}
{"_id": "1311", "text": "Czego nie powinny zawierać materiały i wyroby przeznaczone do kontaktu z żywnością?"}
{"_id": "1312", "text": "Jakie zwierzęta jako dobro ogólnonarodowe stanowią własność Skarbu Państwa?"}
{"_id": "1313", "text": "Kiedy wygasają wzajemne zobowiązania stron?"}
{"_id": "1314", "text": "Kto uchwala regulamin określający szczegółowy tryb działania zarządu NBP?"}
{"_id": "1315", "text": "W jakim terminie wójt musi opublikować informacje o okręgach wyborczych?"}
{"_id": "1316", "text": "Ile wynosi całkowita długość statków rybackich, którą można wykorzystywać w polskich obszarach morskich?"}
{"_id": "1317", "text": "Czy partia polityczna wchodząca w skład koalicji może zgłaszać kandydatów na senatorów samodzielnie?"}
{"_id": "1318", "text": "Czy partia polityczna wchodząca w skład koalicji może zgłaszać kandydatów na senatorów samodzielnie?"}
{"_id": "1319", "text": "Kiedy organ celny może wyrazić zgodę na zastosowanie procedury odprawy czasowej?"}
{"_id": "1320", "text": "Jakiej karze podlega ktoś, kto utrudnia przeprowadzenie kontroli przestrzeganie przepisów ustawy?"}
{"_id": "1321", "text": "Jakiej karze podlega ktoś, kto utrudnia przeprowadzenie kontroli przestrzeganie przepisów ustawy?"}
{"_id": "1322", "text": "Czy ZUS dokona korekty wymiaru składek po złożeniu deklaracji rozliczeniowej przez płatnika po terminie?"}
{"_id": "1323", "text": "Czy brak stanowiska oskarżyciela stoi na przeszkodzie uwzględnienia wniosku?"}
{"_id": "1324", "text": "Czy wszyscy pracownicy PKP są pracownikami kolejowymi?"}
{"_id": "1325", "text": "Czy wszyscy pracownicy PKP są pracownikami kolejowymi?"}
{"_id": "1326", "text": "Kto wydaje certyfikaty zgodności?"}
{"_id": "1327", "text": "Kto wydaje certyfikaty zgodności?"}
{"_id": "1328", "text": "Czy marszałek województwa jest uprawniony do skracania okresów polowań na terenie województwa?"}
{"_id": "1329", "text": "Czy marszałek województwa jest uprawniony do skracania okresów polowań na terenie województwa?"}
{"_id": "1330", "text": "Czy psycholog wykonuje swój zawód samodzielnie?"}
{"_id": "1331", "text": "Czy straty wynikłe z utraty ładunku załadowanego bez wiedzy armatora zalicza się do awarii wspólnej?"}
{"_id": "1332", "text": "W zależności od czego oblicza się opłaty za usunięcie drzew?"}
{"_id": "1333", "text": "W zależności od czego oblicza się opłaty za usunięcie drzew?"}
{"_id": "1334", "text": "W zależności od czego oblicza się opłaty za usunięcie drzew?"}
{"_id": "1335", "text": "Czy funkcjonariusz celny może dostać odznakę honorową?"}
{"_id": "1336", "text": "Czy funkcjonariusz celny może dostać odznakę honorową?"}
{"_id": "1337", "text": "Jaki organ Krajowej Izby jest najwyższym jej organem?"}
{"_id": "1338", "text": "Jaki organ Krajowej Izby jest najwyższym jej organem?"}
{"_id": "1339", "text": "Czy rachmistrze muszą składać przyrzeczenie?"}
{"_id": "1340", "text": "Czy można wejść do lokalu wyborczego z bronią?"}
{"_id": "1341", "text": "Czy można wejść do lokalu wyborczego z bronią?"}
{"_id": "1342", "text": "Czy osoba udzielająca pierwszej pomocy może poświęcić mienie drugiej osoby w stopniu niezbędnym do ratowania życia?"}
{"_id": "1343", "text": "Czy osoba udzielająca pierwszej pomocy może poświęcić mienie drugiej osoby w stopniu niezbędnym do ratowania życia?"}
{"_id": "1344", "text": "Czy źródła finansowania partii politycznych mogą być niejawne?"}
{"_id": "1345", "text": "Czy źródła finansowania partii politycznych mogą być niejawne?"}
{"_id": "1346", "text": "Czy wnuki przyjęte na wychowanie mają prawo do renty po zmarłych rodzicach?"}
{"_id": "1347", "text": "Kiedy kurator składa wniosek o ogłoszenie upadłości osoby prawnej?"}
{"_id": "1348", "text": "Czy dawka promieniowania jonizującego pochodzącego ze źródeł naturalnych może przekroczyć dawkę graniczną?"}
{"_id": "1349", "text": "Czy dawka promieniowania jonizującego pochodzącego ze źródeł naturalnych może przekroczyć dawkę graniczną?"}
{"_id": "1350", "text": "Jaki tytuł ma obecnie Wyższa Szkoła Inżynierska w Koszalinie?"}
{"_id": "1351", "text": "Czy wydanie dyspozycji wyjazdu/wylotu zespołu ratownictwa medycznego w razie konieczności użycia dodatkowych jednostek systemu rodzi roszczenia finansowe?"}
{"_id": "1352", "text": "Co kontroluje okręgowa komisja rewizyjna?"}
{"_id": "1353", "text": "Czy ktoś, kto przewozi materiał jądrowy bez właściwego zabezpeczenia podlega karze ograniczenia wolności?"}
{"_id": "1354", "text": "Czy producent butelek miarowych może przekazać opis przyjętego systemu kontroli wewnętrznej po rozpoczęciu produkcji?"}
{"_id": "1355", "text": "Czy wyborca niepełnosprawny jest dopisywany do spisu wyborców?"}
{"_id": "1356", "text": "Kto wydaje decyzje w sprawach udzielania i pozbawiania azylu w RP?"}
{"_id": "1357", "text": "Kto wydaje decyzje w sprawach udzielania i pozbawiania azylu w RP?"}
{"_id": "1358", "text": "Jak wysoka jest kara dla uchylającego się od służby funkcjonariusza BOR?"}
{"_id": "1359", "text": "Na czyj wniosek inne jednostki organizacyjne mogą uzyskać osobowość prawną?"}
{"_id": "1360", "text": "Czy strona może cofnąć odwołanie przed wydaniem decyzji przez organ odwoławczy?"}
{"_id": "1361", "text": "Kto może określić, w drodze rozporządzenia, dodatkowe kryteria akredytacyjne?"}
{"_id": "1362", "text": "Na kim spoczywa obowiązek prowadzenia kontroli źródeł promieniowania jonizującego?"}
{"_id": "1363", "text": "Co może ustalić organ ochrony środowiska w drodze decyzji?"}
{"_id": "1364", "text": "Kto określi w drodze rozporządzenia rodzaje preparatów i ich ilości jakie mogą posiadać zakłady opieki?"}
{"_id": "1365", "text": "Kto wykonuje zadania wojewody w zakresie ochrony przyrody na terenie parku narodowego?"}
{"_id": "1366", "text": "Jaki akt wygasa wraz z dniem powołania Prezesa UDT?"}
{"_id": "1367", "text": "Na czyje rządanie organ podatkowy podejmuje postępowanie?"}
{"_id": "1368", "text": "Na czyj wniosek rada ministrów określa tryb powierzania mienia kierownikom urzędów państwowych?"}
{"_id": "1369", "text": "Jak wysoka była inwestycja na linie kolejowe o państwowym znaczeniu?"}
{"_id": "1370", "text": "Jaka kwota z funduszu operacyjnego może być przeznaczona na wypłaty w pierwszym roku?"}
{"_id": "1371", "text": "Czy na rozprawie mogą być obecne osoby w stanie nie licującym z powagą sądu?"}
{"_id": "1372", "text": "Czy urzędnik służby cywilnej ponosi opłaty z tytułu uczestnictwa w szkoleniach?"}
{"_id": "1373", "text": "Jak długo trwa kadencja rady powiatu?"}
{"_id": "1374", "text": "Kwoty przeznaczone do podziału wspólników nie mogą przekroczyć zysku za jaki rok?"}
{"_id": "1375", "text": "Jakie mogą być najniższe udziały powstałe w wyniku podziału?"}
{"_id": "1376", "text": "Czy sąd może przesłuchać wszelkich uczestników sprawy, której akta zginęły?"}
{"_id": "1377", "text": "Czy producentowi bazy danych przysłubuje prawo pobierania danych?"}
{"_id": "1378", "text": "W jaki sposób wójt, burmistrz lub prezydent miasta wybiera dziennych opiekunów?"}
{"_id": "1379", "text": "Czy do zadań dyrektora urzędu celnego należy pobieranie należności celnych?"}
{"_id": "1380", "text": "Czy komisja posiada możliwość wydania decyzji o odmowie udzielenia zezwolenia w przypadku nie otrzymania rękojmi należytego wykonywania obowiązków?"}
{"_id": "1381", "text": "Czy komisja posiada możliwość wydania decyzji o odmowie udzielenia zezwolenia w przypadku nie otrzymania rękojmi należytego wykonywania obowiązków?"}
{"_id": "1382", "text": "Czy komisja posiada możliwość wydania decyzji o odmowie udzielenia zezwolenia w przypadku nie otrzymania rękojmi należytego wykonywania obowiązków?"}
{"_id": "1383", "text": "Czy Premier Rzeczypospolitej Polskiej otrzymał zgodę na dokonanie ratyfikacji Konwencji o pomocy prawnej?"}
{"_id": "1384", "text": "Czy Premier Rzeczypospolitej Polskiej otrzymał zgodę na dokonanie ratyfikacji Konwencji o pomocy prawnej?"}
{"_id": "1385", "text": "Czy Premier Rzeczypospolitej Polskiej otrzymał zgodę na dokonanie ratyfikacji Konwencji o pomocy prawnej?"}
{"_id": "1386", "text": "Czy Najwyższa Izba Kontroli przeprowadza kontrolę pod względem dochodowości?"}
{"_id": "1387", "text": "Czy Najwyższa Izba Kontroli przeprowadza kontrolę pod względem dochodowości?"}
{"_id": "1388", "text": "Czy Najwyższa Izba Kontroli przeprowadza kontrolę pod względem dochodowości?"}
{"_id": "1389", "text": "W jakiej formie Minister Obrony Narodowej określi warunki i tryb tworzenia wewnętrznych służb ochrony?"}
{"_id": "1390", "text": "W jakiej formie Minister Obrony Narodowej określi warunki i tryb tworzenia wewnętrznych służb ochrony?"}
{"_id": "1391", "text": "Jakie dokumenty mogą zostać dołączone do protokołu w przypadku zezwolenia organu podatkowego?"}
{"_id": "1392", "text": "Jakie postępowanie może wszcząć Minister Gospodarki?"}
{"_id": "1393", "text": "Jakie postępowanie może wszcząć Minister Gospodarki?"}
{"_id": "1394", "text": "Jakie organy są organami stanowiącymi jednostek samorządu terytorialnego?"}
{"_id": "1395", "text": "Czy do zadań komendanta wojewódzkiego Państwowej Straży Pożarnej należy gromadzenie i opracowanie informacji uzyskiwanych z systemów obserwacji?"}
{"_id": "1396", "text": "Czy do zadań komendanta wojewódzkiego Państwowej Straży Pożarnej należy gromadzenie i opracowanie informacji uzyskiwanych z systemów obserwacji?"}
{"_id": "1397", "text": "Czy do zadań komendanta wojewódzkiego Państwowej Straży Pożarnej należy gromadzenie i opracowanie informacji uzyskiwanych z systemów obserwacji?"}
{"_id": "1398", "text": "Czy do zadań komendanta wojewódzkiego Państwowej Straży Pożarnej należy gromadzenie i opracowanie informacji uzyskiwanych z systemów obserwacji?"}
{"_id": "1399", "text": "Czy głosowanie może odbyć się przy użyciu kart do głosowania dowolnego pochodzenia?"}
{"_id": "1400", "text": "Czy głosowanie może odbyć się przy użyciu kart do głosowania dowolnego pochodzenia?"}
{"_id": "1401", "text": "Jaki urząd ma prawo wezwać spółkę do usunięcia braków wynikających z niedopełnienia przepisów?"}
{"_id": "1402", "text": "Jaki urząd ma prawo wezwać spółkę do usunięcia braków wynikających z niedopełnienia przepisów?"}
{"_id": "1403", "text": "Jaki urząd ma prawo wezwać spółkę do usunięcia braków wynikających z niedopełnienia przepisów?"}
{"_id": "1404", "text": "Czy grupa znajdzie się w rejestrze grup uznanych jeśli nie osiągnęła wartości sprzedaży równej 100 tys. EURO?"}
{"_id": "1405", "text": "Czy grupa znajdzie się w rejestrze grup uznanych jeśli nie osiągnęła wartości sprzedaży równej 100 tys. EURO?"}
{"_id": "1406", "text": "Czy zamawiający ma prawo zachowywać prowadzone negocjacje w tajemnicy w dowolnej sytuacji?"}
{"_id": "1407", "text": "Czy zamawiający ma prawo zachowywać prowadzone negocjacje w tajemnicy w dowolnej sytuacji?"}
{"_id": "1408", "text": "Czy wierzyl wspólnika ma prawo uzyskać zajęcie dowolnych praw służących wspólnikowi?"}
{"_id": "1409", "text": "Czy wierzyl wspólnika ma prawo uzyskać zajęcie dowolnych praw służących wspólnikowi?"}
{"_id": "1410", "text": "Czy absolwent szkoły położnych uzyskuje tytuł zawodowy pielęgniarka?"}
{"_id": "1411", "text": "Czy absolwent szkoły położnych uzyskuje tytuł zawodowy pielęgniarka?"}
{"_id": "1412", "text": "Jakich dokumentów potrzebuje osoba, której świadczenia rodzinne wypłaca pracodawca w celu ustalenia prawa do tych świadczeń?"}
{"_id": "1413", "text": "Czy minister właściwy do spraw finansów jest upoważniony do przekazania instytucjom ubezpieczeniowym środków finansowych z ulg?"}
{"_id": "1414", "text": "Czy organ emerytalny ma obowiązek wznowienia wypłaty świadczeń w przypadku wpłynięcia wniosku o wznowienie wypłaty?"}
{"_id": "1415", "text": "Czy organ emerytalny ma obowiązek wznowienia wypłaty świadczeń w przypadku wpłynięcia wniosku o wznowienie wypłaty?"}
{"_id": "1416", "text": "Czy zakłady zachowawcze zaliczane są do grupy działalności charytatywnych jakie mogą prowadzić gminy żydowskie?"}
{"_id": "1417", "text": "Czy zakłady zachowawcze zaliczane są do grupy działalności charytatywnych jakie mogą prowadzić gminy żydowskie?"}
{"_id": "1418", "text": "Jaką jednostkę jest zobowiązany powiadomić zarząd w przypadku nabycia własnych akcji?"}
{"_id": "1419", "text": "Jaką jednostkę jest zobowiązany powiadomić zarząd w przypadku nabycia własnych akcji?"}
{"_id": "1420", "text": "Czy inspektor może przeprowadzić kontrolę statku w przypadku uzasadnionego podejrzenia o naruszeniu przepisów?"}
{"_id": "1421", "text": "Czy inspektor może przeprowadzić kontrolę statku w przypadku uzasadnionego podejrzenia o naruszeniu przepisów?"}
{"_id": "1422", "text": "Czy inspektor może przeprowadzić kontrolę statku w przypadku uzasadnionego podejrzenia o naruszeniu przepisów?"}
{"_id": "1423", "text": "Jakiej odpowiedzialności podlegają członkowie samorządu psychologów za naruszenie obowiązków zawodowych?"}
{"_id": "1424", "text": "Czy do odwołania Prezydenta miasta stołecznego Warszawy konieczna jest bezwzględna większość głosów ustawowego składu Rady?"}
{"_id": "1425", "text": "Czy w przypadku uchylenia orzeczenia, o którym mowa w art. 74 pkt. 5 jego skutki zostają uchylone w całości?"}
{"_id": "1426", "text": "Czy producentowi dopiero rozpoczynającemu produkcję mleka określa się referencyjną wartość tłuszczu?"}
{"_id": "1427", "text": "Jakie przepisy określają nielegalne wprowadzenie towaru?"}
{"_id": "1428", "text": "Jakie przepisy określają nielegalne wprowadzenie towaru?"}
{"_id": "1429", "text": "Czy jednostki badawczo-rozwojowe zwolnione są z opłat według art. 18a?"}
{"_id": "1430", "text": "Czy jednostki badawczo-rozwojowe zwolnione są z opłat według art. 18a?"}
{"_id": "1431", "text": "Jakim przepisom podlegają przychody kościelnych osób prawnych?"}
{"_id": "1432", "text": "Jakim przepisom podlegają przychody kościelnych osób prawnych?"}
{"_id": "1433", "text": "Jakim przepisom podlegają przychody kościelnych osób prawnych?"}
{"_id": "1434", "text": "Jakim przepisom podlegają przychody kościelnych osób prawnych?"}
{"_id": "1435", "text": "Jakim przepisom podlegają przychody kościelnych osób prawnych?"}
{"_id": "1436", "text": "Według jakiego prawa wyraz \"kosmetyki\" zastępuje się wyrazami \"produkty kosmetyczne\"?"}
